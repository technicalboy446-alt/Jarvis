# Target 33 — Final Security & Reliability Audit

## Fixed findings

### 1. Bearer token lifetime
Dashboard bearer tokens previously had no explicit expiry. Target 33 adds an 8-hour
TTL and pruning of expired token/session state.

### 2. Device session lifetime and rotation
Persistent device sessions previously had no expiry. Target 33 adds a 30-day device
TTL and rotates the session key on reconnect.

### 3. Login abuse resistance
PIN/device-login endpoints now use an in-memory per-client rate limit of 8 attempts per
60 seconds and return HTTP 429 once the threshold is exceeded.

### 4. Secret redaction
Security logging now redacts JSON-style API-key, password, token, and X-API-Key values
in addition to the original plain-text forms.

### 5. Audit-log filesystem permissions
Security audit logs are best-effort restricted to owner read/write (`0600`) on POSIX-like
systems both at creation and append time.

### 6. Resource-pressure admission
The Target 32 resource manager is carried into the production runtime and exposes memory
pressure classification, bounded caching, concurrency limits, and a critical-pressure
admission guard.

## Residual risks reviewed

### Model-generated desktop code
The existing desktop automation path still executes generated Python through a reduced
namespace. This remains a security-sensitive capability and is deliberately retained for
feature compatibility. The prompt and injected namespace prohibit subprocess/import paths,
but this is not equivalent to a kernel sandbox.

### Local HTTP fallback
The dashboard can operate over plain HTTP when certificate generation/dependencies are
unavailable. LAN exposure should therefore be treated as trusted-network functionality;
HTTPS is preferred whenever the local certificate path is available.

### Shell-backed OS utilities
Some platform-specific helper actions still use `shell=True` with project-authored command
strings. These were reviewed as existing platform adapters rather than newly introduced
remote-input execution paths.

## Decision

No new blocking security defect was introduced by Target 33. The two residual risks above
remain explicitly documented and bounded rather than being hidden behind a false claim of
complete sandbox isolation or universal TLS.
