# JARVIS 35.0.3 — Final Working Production Build

This is the corrected production package built from Targets 0–35.

Entry point: `main.py`
Version: `35.0.3`
Target: `35`

## Install / launch

Windows: `scripts\install_windows.bat` then `scripts\run_windows.bat`
macOS/Linux: `bash scripts/install_unix.sh` then `bash scripts/run_unix.sh`

See `DEPLOYMENT.md` and `FINAL_PRODUCTION_BUILD.md`.
