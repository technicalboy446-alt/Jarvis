# Target 17 — Unified Orchestration & End-to-End Integration

Target 17 adds one canonical request lifecycle across existing JARVIS interfaces and engines.
It composes the Target 3 router, Target 4 agent system and Target 16 security boundary without
replacing them.

```text
Text / Voice / Dashboard / Desktop
              |
              v
     OrchestrationRequest
              |
              v
       Target 17 Orchestrator
        /        |          \
   route     security      context
      |           |             |
      +-----------+-------------+
                  v
           AgentManager
                  |
                  v
          Existing Agent/Tool
                  |
                  v
        Normalized Result + Audit
```

## Guarantees

- All supported request surfaces share one orchestration contract.
- Existing router remains the source of truth for initial classification.
- Existing AgentManager remains the source of truth for agent dispatch.
- Target 16 security remains the source of truth for security auditing.
- Errors are normalized into `OrchestrationResult` instead of leaking exceptions to callers.
- Request IDs and source metadata follow a request through the lifecycle.
