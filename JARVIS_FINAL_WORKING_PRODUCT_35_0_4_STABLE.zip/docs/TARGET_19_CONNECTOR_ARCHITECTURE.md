# TARGET 19 — CONNECTOR & INTEGRATION GATEWAY

Target 19 adds a canonical connector boundary over the integrations already present in
JARVIS. It does not replace Google Sheets, WhatsApp, email, browser, storage, or Hermes
platform adapters. It standardizes discovery, health checks, guarded invocation,
audit/redaction, and observability.

## Flow

Input / agent / automation
  -> ConnectorGateway
  -> SecurityManager authorization
  -> existing native connector adapter
  -> normalized ConnectorResult
  -> Target 18 observability + Target 16 audit

## Core files

```text
connectors/
├── models.py
├── registry.py
├── gateway.py
└── google_sheets/integration.py
```
