# Target 25 — Multimodal Input & Document Understanding

Target 25 adds a canonical attachment contract and deterministic local extraction layer.

## Supported inputs
- Text/Markdown/JSON/YAML/config files
- CSV/TSV/XLSX/XLSM spreadsheets
- DOCX/PPTX documents
- PDF when optional `pypdf` is installed; otherwise the file is preserved as a media/document attachment with safe metadata
- Images through safe metadata probing (Pillow)
- Audio/video as bounded media attachments for future native model handling

## Flow
`Input -> OrchestrationRequest.attachments -> MultimodalManager -> ExtractionResult -> AgentRequest.metadata`

Extracted attachment text is bounded. Failures are isolated per attachment and reported in metadata rather than crashing the request.
