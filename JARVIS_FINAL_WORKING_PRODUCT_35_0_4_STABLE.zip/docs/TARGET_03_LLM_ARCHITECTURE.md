# Target 3 — Unified LLM Architecture

JARVIS now has a provider-neutral text LLM contract under `core/llm/`.

## Providers

- `ollama` — local Ollama `/api/chat` backend; can attempt to start `ollama serve` when unreachable.
- `openai` / `openai_compatible` / `lmstudio` / `localai` / `jan` / `llamacpp` / `openrouter` — OpenAI-compatible `/v1/chat/completions` backend.
- `gemini` — Google Gen AI SDK `models.generate_content` and `models.generate_content_stream` for text generation.

The existing MARK LII `core/llm_client.py` remains untouched as a compatibility implementation. The new facade delegates new JARVIS code to `core/llm/client_adapter.py`.

## Runtime selection

Selection order:

1. `JARVIS_LLM_PROVIDER` / `JARVIS_LLM_MODEL` / `JARVIS_LLM_URL` environment variables where supplied.
2. `config/api_keys.json`.
3. Provider defaults.

Provider credentials can be supplied by environment variables (`GEMINI_API_KEY`, `OPENAI_API_KEY`, `OPENROUTER_API_KEY`) or by the JSON config.

## Scope boundary

Target 3 does **not** replace the MARK LII Gemini Live voice session in `main.py`. The Live API is a separate real-time audio interface. This target establishes a common provider layer for text generation, planning, data querying, routing and future agents.

## Standard contract

`LLMRequest` → provider → `LLMResponse` or `LLMStreamEvent`.

The common response format normalizes provider differences, including OpenAI-style tool calls and Ollama tool calls.
