# Target 07 — Google Sheets Architecture

Google Sheets is an external data source behind `connectors/google_sheets`. The connector owns OAuth, spreadsheet discovery, reads, explicit writes, and audit events. The data engine owns normalization and validation. Business logic is outside the connector.

## Flow

Google OAuth → GoogleSheetsClient → GoogleSheetsDataSource → Dataset → normalization/validation → business engine

Writes are disabled by default. A write must be explicitly enabled and carries an audit reason.
