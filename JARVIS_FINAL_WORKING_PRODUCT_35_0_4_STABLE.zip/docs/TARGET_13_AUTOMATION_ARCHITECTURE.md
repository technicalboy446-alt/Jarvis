# Target 13 — Automation Architecture

Automation is a canonical JARVIS layer for scheduled jobs, triggers, checks, and alerts.

## Flow

User/agent request -> JobSpec -> AutomationStore -> Scheduler/Engine -> registered handler -> JobRun/audit record.

## Safety

Jobs are read-only by default. Write-enabled jobs require both `read_only=False` and explicit `metadata.allow_write=true`.

## Persistence

- `jobs.json` stores job definitions.
- `runs.jsonl` stores execution records.

## Scheduling

The current scheduler supports a lightweight local tick model and simple schedule expressions (`manual`, `every_run`, `daily`, `hourly`, and `weekday:mon,tue,...`). A later production target can replace this with OS/background scheduling without changing the job contract.

## Alerts

`AlertManager` stores structured alerts and `CheckRunner` turns failed checks into alerts.

## Scope

This target does not yet connect scheduled jobs to Google Sheets writes, WhatsApp, email, or external cron services. Those are later integrations and must go through the existing Tool System safety layer.
