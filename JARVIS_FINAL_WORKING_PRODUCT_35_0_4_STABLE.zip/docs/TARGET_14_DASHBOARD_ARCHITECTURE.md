# Target 14 — Dashboard Architecture

The dashboard is the read-only browser control surface for JARVIS.

## Sources
- `dashboard/server.py`: existing authenticated LAN server and WebSocket UI.
- `dashboard/api.py`: canonical dashboard snapshot services.
- `dashboard/routes.py`: route-level service wrappers.
- `dashboard/static/business.html`: business/status dashboard.

## Flow
Browser -> authenticated dashboard -> snapshot API -> workspace/automation/system services.

## Ownership
The dashboard displays state; it does not own business calculations, data normalization, or automation execution.

## Security
The existing server authentication remains authoritative. The business snapshot endpoint requires the same bearer-token authentication.
