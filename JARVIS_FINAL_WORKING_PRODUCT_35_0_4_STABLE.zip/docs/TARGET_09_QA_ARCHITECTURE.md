# Target 9 — Business Question Answering Architecture

JARVIS answers business questions through a read-only pipeline:

Question → deterministic intent parser → QueryPlan → business executor → grounded formatter.

The engine does not directly let the LLM invent values. It receives domain records from the data/business layers and returns evidence with the calculated result.

Current intents: trip count, trip quantity, expenses total, payments total, outstanding balance.

Date filters currently support today and yesterday. Company/material/vehicle/entity extraction is intentionally reserved for later expansion when real source schemas are connected.
