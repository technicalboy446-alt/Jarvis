# Target 20 — Automation & Workflow Runtime

Target 20 completes the existing automation/scheduler foundation without replacing it.

## Architecture

Scheduler -> WorkflowRuntime -> AutomationEngine handler -> result/history

The runtime adds:
- retry policy with bounded exponential backoff
- durable idempotency index for scheduled execution keys
- bounded concurrency
- failure alerts
- Target 18 observability events/metrics
- preservation of Target 16 write-policy guards

Existing `automation/engine.py`, `automation/store.py`, and `scheduler/scheduler.py` remain compatible.
