# Target 22 — Knowledge Architecture

```text
Knowledge Documents
       |
       v
KnowledgeIndex
       |
       v
KnowledgeRetriever
       |
       v
RetrievalResult
       |
       v
GroundingContextBuilder
       |
       +------> Direct knowledge queries
       |
       +------> Optional Target 17 orchestration metadata
                     |
                     v
                 AgentRequest
```

The retrieval layer is deterministic, bounded, local, and fail-safe. A no-match result is explicitly marked ungrounded, preventing accidental presentation of unsupported evidence.
