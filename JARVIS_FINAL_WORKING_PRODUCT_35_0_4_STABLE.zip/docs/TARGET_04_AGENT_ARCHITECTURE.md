# Target 4 — Agent Architecture

## Canonical design

JARVIS owns the agent contract and lifecycle. Hermes is integrated behind an adapter.

```text
User
  ↓
Router
  ↓
AgentManager
  ↓
AgentRegistry
  ↓
HermesAgentAdapter
  ↓
Hermes AIAgent runtime
```

## Rules

1. New JARVIS agents implement the `Agent`/`BaseAgent` contract.
2. The registry is the only canonical discovery mechanism.
3. Heavy agent runtimes are loaded lazily.
4. Hermes remains a capability provider, not a competing application entry point.
5. Business-specialized agents are intentionally deferred until the data and tool layers are available.
