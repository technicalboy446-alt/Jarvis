# Target 22 — Knowledge Retrieval & Grounding

Target 22 adds a deterministic local knowledge layer that can index project/business knowledge, retrieve ranked evidence, build bounded grounding context, and optionally attach that evidence to the canonical Target 17 orchestration request.

## Subtargets
- 22.1 Knowledge document/chunk contracts
- 22.2 Deterministic local knowledge index
- 22.3 Ranked retrieval with grounded/no-match states
- 22.4 Bounded grounding context
- 22.5 Knowledge manager lifecycle API
- 22.6 Optional orchestration grounding integration
- 22.7 Focused tests
- 22.8 Regression/compile/package validation

The layer uses the Python standard library only and does not replace the existing router, agents, memory, data, reporting, connectors, automation, security, observability, or voice systems.
