# Target 23 — LLM Provider & Model Routing

Target 23 adds an opt-in provider/model routing layer over the existing provider-neutral LLM facade.

## Capabilities
- Preserve the existing configured primary provider as the first route.
- Support ordered `llm_fallbacks` entries in `config/api_keys.json`.
- Retry recoverable provider failures using a clean fallback request.
- Never splice two partial streaming providers into one response.
- Apply a bounded cooldown after provider failures.
- Keep provider-specific implementation behind the existing provider contract.
- Preserve legacy `core.llm_client` compatibility exports.

## Configuration example
```json
{
  "llm_provider": "ollama",
  "llm_model": "llama3.2",
  "llm_url": "http://localhost:11434",
  "llm_fallbacks": [
    {"provider": "openai", "model": "local-model", "url": "http://localhost:1234"}
  ]
}
```

Fallbacks are not required. With no `llm_fallbacks`, behavior remains the existing primary-provider path.
