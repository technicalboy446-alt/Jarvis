# Target 21 — Memory Intelligence & Lifecycle

Target 21 adds a deterministic policy layer over the existing memory store/backends.

## Subtargets
- 21.1 Memory relevance ranking
- 21.2 TTL/expiration enforcement
- 21.3 Expired-memory purge
- 21.4 Sensitive-memory redaction in generated context
- 21.5 Bounded context construction
- 21.6 Compatibility with existing memory API/backends
- 21.7 Target 21 test suite
- 21.8 Regression/compile/package validation

The layer does not replace existing memory stores or Hermes memory adapters.
