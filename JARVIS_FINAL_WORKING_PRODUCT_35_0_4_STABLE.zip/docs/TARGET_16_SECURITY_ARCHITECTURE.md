# Target 16 — Security & Safety Architecture

Target 16 adds a canonical, fail-closed security layer around the existing JARVIS engines.
It does not replace the Target 5 tool policy, Target 11 workspace manager, Target 12 memory,
Target 13 automation, Target 14 dashboard, or Target 15 voice interface.

## Scope

```text
Request / Voice / UI
        ↓
Existing JARVIS router and tools
        ↓
Target 16 Security Boundary
   ├─ permission policy
   ├─ path containment
   ├─ secret redaction
   ├─ audit trail
   └─ confirmation hardening
        ↓
Existing execution / business / data layers
```

## Guarantees

- Unknown or disallowed permission levels fail closed.
- Destructive and administrative operations do not become implicitly allowed.
- Workspace-relative paths cannot escape the configured security root.
- Common API key, bearer token, password and token patterns are redacted in audit payloads.
- Security decisions and tool results are recorded as append-only JSONL events.
- Existing human confirmation remains authoritative for irreversible actions.

## Boundary

Target 16 introduces reusable security primitives and a single `SecurityManager` facade. Existing
Targets 0–15 remain the source of truth for their respective engines and are not replaced.
