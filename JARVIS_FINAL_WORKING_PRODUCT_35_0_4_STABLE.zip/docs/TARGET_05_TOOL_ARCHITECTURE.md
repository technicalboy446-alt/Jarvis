# JARVIS Target 5 — Tool Architecture

## Purpose
Create one canonical execution boundary for all JARVIS tools without forcing an immediate migration of MARK LII or Hermes implementations.

## Canonical components
- `tools/base_tool.py` — tool contract, permissions, context, and result envelope.
- `tools/registry.py` — discovery and registration.
- `tools/policy.py` — permission policy.
- `tools/executor.py` — validation, confirmation handling, execution timeout, and normalized results.
- `core/confirm.py` — human confirmation gate for destructive/admin actions.
- `core/undo.py` — existing reversible-action recovery layer.

## Permission levels
`READ` → non-mutating access.

`WRITE` → reversible state changes such as edits/updates.

`DESTRUCTIVE` → actions that can remove or cause irreversible change.

`ADMIN` → system/security/configuration actions with elevated impact.

## Runtime rules
1. Tool implementations remain behind the JARVIS contract.
2. Registry owns discovery; executor owns execution.
3. Policy is checked before execution.
4. Destructive/admin tools are disabled by default.
5. Destructive/admin tools can also require an explicit interface confirmation.
6. Tool execution has a configurable timeout.
7. Every execution returns a structured `ToolResult`.
8. Existing MARK LII/Hermes tools are not mass-migrated in this target; adapters will be added incrementally in later integration work.

## Deferred work
- Bulk migration of existing MARK LII actions.
- Business-specific tools.
- Google Sheets tools.
- Tool schema generation for LLM function calling.
- Per-user/per-agent permission profiles.
