# Target 8 — Business Intelligence Architecture

Business rules sit above the canonical Data Engine. Domain models represent companies, vehicles, materials, trips, expenses and payments. Pricing, trip calculations, expenses, payments and validation are separate services so each can be tested independently.

Flow: Dataset -> domain mapping -> business engine -> answers/reports.

Target 8 intentionally does not implement Google-specific logic, report formatting, invoice generation, or PDF generation. Those remain separate targets.
