# Target 10 — Reporting Engine

The reporting engine is a deterministic presentation layer over the locked business engine. It builds structured Report objects for trip, expense, payment and management summaries, then renders them to portable CSV or JSON files. PDF generation is intentionally excluded, and no report builder changes source records.

Flow: verified business records → period filter → report builder → Report model → renderer → workspace/reports.
