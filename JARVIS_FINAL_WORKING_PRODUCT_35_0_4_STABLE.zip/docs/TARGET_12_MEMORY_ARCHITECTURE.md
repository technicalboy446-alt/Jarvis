# Target 12 — Memory Architecture

JARVIS uses one memory interface with four explicit scopes: `short_term`, `business`, `preference`, and `long_term`.

- Short-term memory requires a TTL and is intended for transient session facts.
- Business memory stores durable operational facts and rules.
- Preference memory stores durable user preferences.
- Long-term is a general durable scope for facts that do not belong to the two specialized durable categories.

The runtime interface lives in `memory/interface.py`; storage is behind `memory/store.py`.
External Hermes memory providers remain source material only and are not activated by this target.
Sensitive records are flagged in the record metadata and are not automatically surfaced by any prompt formatter.
