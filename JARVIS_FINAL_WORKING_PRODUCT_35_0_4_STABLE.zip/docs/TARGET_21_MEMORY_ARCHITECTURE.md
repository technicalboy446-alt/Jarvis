# Target 21 — Memory Architecture

```text
Existing Memory Stores / Backends
             |
             v
       JarvisMemory API
             |
             v
     MemoryIntelligence
      /      |       \
 ranking   lifecycle   context
      |       |         |
      +-------+---------+
              v
       Orchestration Context
```

Sensitive records are omitted from generated context values. Expired records remain governed by the existing store TTL behavior; the intelligence layer filters them from ranked retrieval and exposes a cleanup operation.
