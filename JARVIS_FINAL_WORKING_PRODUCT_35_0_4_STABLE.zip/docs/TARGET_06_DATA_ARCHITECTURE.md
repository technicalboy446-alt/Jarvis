# Target 6 — Data Engine Architecture

The JARVIS data engine provides one internal representation for tabular business data regardless of whether the input came from CSV, Excel, Pandas, or (in Target 7) Google Sheets.

## Layers

1. **Loaders** — convert external tabular sources into `Dataset`.
2. **Normalization** — map aliases to canonical fields and normalize dates/numbers/text.
3. **Validation** — detect duplicate keys and business-data inconsistencies that are safe to identify at the generic layer.
4. **Pipeline** — exposes source-specific ingest functions without coupling business logic to file formats.
5. **Qanat** — preserved as a source/pipeline capability, but not made the canonical business data model.

## Canonical fields currently recognized

`date`, `vehicle_id`, `driver`, `material`, `quantity`, `gross_weight`, `empty_weight`, `unit_price`, `total`

The alias dictionary is intentionally extensible. Company-specific fields and rules belong in later business-layer targets.

## Status

Target 6 is locked. The next layer is Google Sheets integration (Target 7), which should adapt Google Sheets rows into `Dataset` rather than create a second data model.
