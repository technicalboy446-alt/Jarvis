# Target 11 — File Management Architecture

JARVIS uses `workspace/file_manager.py` as the canonical automated filing layer.

## Flow

incoming -> processing -> processed -> archives
                 |\
                 +-> reports
                 +-> statements

The manager sanitizes filenames, prevents category traversal, avoids accidental overwrite by default, records SHA-256 metadata, supports search, and keeps an append-only manifest.

Desktop/system-wide file automation remains behind the existing Tool System and MARK LII file controller. Target 11 does not replace those capabilities; it establishes the business workspace's canonical filing layer.
