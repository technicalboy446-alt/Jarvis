# Target 15 — Voice Interface Architecture

## Purpose

Target 15 exposes one canonical voice interface around the existing MARK LII/JARVIS voice runtime.
It is an integration layer, not a replacement voice engine.

## Existing engines retained

- Existing JARVIS/Gemini Live microphone and realtime audio path
- Existing STT modules
- Existing TTS modules
- Existing audio-device handling
- Existing interruption behavior
- Existing session resumption/reconnect handling
- Existing `core.confirm` human confirmation gate

## Canonical interface

```text
interface/voice/
├── voice_manager.py
├── input.py
├── output.py
├── session.py
└── __init__.py
```

## Flow

```text
Microphone / existing Live audio
        ↓
Existing JARVIS STT / Live transcription
        ↓
VoiceInput
        ↓
VoiceManager
        ↓
Existing JARVIS text-command entry point
        ↓
Existing router / agents / tools / data / business systems
        ↓
Existing response path
        ↓
VoiceOutput
        ↓
Existing JARVIS speaker / Live audio
```

## Safety

Confirmation is never generated or accepted by the voice layer. The existing `core.confirm` interface gate remains authoritative. A pending confirmation is only surfaced as a pending state; the voice layer never auto-confirms it.

## Error handling

- Input submission failures are captured in `VoiceInput.state.error`.
- STT failures return an empty transcript through the adapter and preserve the error for diagnostics.
- Output failures call the configured text/UI fallback rather than disappearing silently.
- Session interrupt/reconnect failures enter the explicit error state.

## Target boundary

No Target 0–14 business/data/dashboard implementation is changed by this target.
