# Tool Migration Map

| Source family | Current status | Target owner | Migration point |
|---|---|---|---|
| MARK LII actions | preserved | `JARVIS/tools` | incremental adapters |
| Hermes tools | preserved | `JARVIS/tools` | incremental adapters |
| Google Workspace | preserved in connectors/skills | `JARVIS/tools` + `data` | Target 7 |
| Business actions | not yet built | `JARVIS/tools` | Target 8 |
| System/admin actions | preserved | `JARVIS/tools` | security hardening later |
