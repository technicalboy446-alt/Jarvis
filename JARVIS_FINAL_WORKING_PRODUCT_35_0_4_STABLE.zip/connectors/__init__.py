"""Canonical connector integration layer."""
from .gateway import ConnectorCall, ConnectorGateway
from .models import ConnectorResult
from .registry import ConnectorRegistry

__all__ = ["ConnectorCall", "ConnectorGateway", "ConnectorRegistry", "ConnectorResult"]
