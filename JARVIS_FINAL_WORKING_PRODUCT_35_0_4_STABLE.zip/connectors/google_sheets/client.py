from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

@dataclass(frozen=True)
class SheetRef:
    spreadsheet_id: str
    title: str
    sheet_id: int | None = None

@dataclass
class AuditEvent:
    operation: str
    spreadsheet_id: str
    range_name: str | None = None
    rows_affected: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

class GoogleSheetsClient:
    """Thin Google Sheets adapter returning JARVIS-native rows and datasets."""
    def __init__(self, service: Any, *, audit: Callable[[AuditEvent], None] | None = None, allow_writes: bool = False):
        self.service = service
        self.audit = audit
        self.allow_writes = allow_writes

    @classmethod
    def from_oauth(cls, credentials_path: str | Path, token_path: str | Path, *, audit=None, allow_writes=False):
        from .auth import load_credentials
        try:
            from googleapiclient.discovery import build
        except ImportError as exc:
            raise RuntimeError("google-api-python-client is required for Google Sheets") from exc
        creds=load_credentials(credentials_path, token_path)
        return cls(build("sheets", "v4", credentials=creds), audit=audit, allow_writes=allow_writes)

    def _record(self, event: AuditEvent):
        if self.audit: self.audit(event)

    def list_sheets(self, spreadsheet_id: str) -> list[SheetRef]:
        data=self.service.spreadsheets().get(spreadsheetId=spreadsheet_id, fields="sheets(properties(sheetId,title))").execute()
        return [SheetRef(spreadsheet_id, s["properties"]["title"], s["properties"].get("sheetId")) for s in data.get("sheets", [])]

    def discover_schema(self, spreadsheet_id: str, sheet_title: str, sample_rows: int = 5) -> dict[str, Any]:
        values=self.read_values(spreadsheet_id, f"'{sheet_title}'", max_rows=sample_rows+1, normalize=False)
        headers=values[0] if values else []
        return {"spreadsheet_id": spreadsheet_id, "sheet": sheet_title, "headers": headers, "sample_rows": values[1:sample_rows+1] if values else [], "column_count": len(headers)}

    def read_values(self, spreadsheet_id: str, range_name: str, *, max_rows: int | None = None, normalize: bool = True):
        from data.loaders import from_rows
        result=self.service.spreadsheets().values().get(spreadsheetId=spreadsheet_id, range=range_name).execute()
        values=result.get("values", [])
        if max_rows is not None: values=values[:max_rows]
        if not normalize: return values
        if not values: return from_rows([], source=f"gsheets:{spreadsheet_id}:{range_name}")
        headers=[str(h).strip() if h is not None else "" for h in values[0]]
        rows=[]
        for raw in values[1:]:
            row={h:(raw[i] if i < len(raw) else None) for i,h in enumerate(headers) if h}
            rows.append(row)
        ds=from_rows(rows, source=f"gsheets:{spreadsheet_id}:{range_name}")
        from data.normalization import normalize as normalize_dataset
        return normalize_dataset(ds)

    def write_values(self, spreadsheet_id: str, range_name: str, values: Sequence[Sequence[Any]], *, input_option: str = "USER_ENTERED", reason: str = "") -> dict[str, Any]:
        self._assert_write_allowed()
        body={"values": [list(v) for v in values]}
        result=self.service.spreadsheets().values().update(spreadsheetId=spreadsheet_id, range=range_name, valueInputOption=input_option, body=body).execute()
        self._record(AuditEvent("write_values", spreadsheet_id, range_name, len(values), {"reason": reason, "input_option": input_option}))
        return result

    def append_rows(self, spreadsheet_id: str, range_name: str, rows: Sequence[Sequence[Any]], *, input_option: str = "USER_ENTERED", reason: str = "") -> dict[str, Any]:
        self._assert_write_allowed()
        body={"values": [list(v) for v in rows]}
        result=self.service.spreadsheets().values().append(spreadsheetId=spreadsheet_id, range=range_name, valueInputOption=input_option, insertDataOption="INSERT_ROWS", body=body).execute()
        self._record(AuditEvent("append_rows", spreadsheet_id, range_name, len(rows), {"reason": reason, "input_option": input_option}))
        return result

    def _assert_write_allowed(self):
        if not self.allow_writes:
            raise PermissionError("Google Sheets write access is disabled; enable it explicitly in the JARVIS configuration")
