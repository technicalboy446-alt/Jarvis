"""Optional gateway adapter for the existing Google Sheets client."""
from __future__ import annotations

from typing import Any, Mapping

from tools.base_tool import Permission

from .adapter import GoogleSheetsDataSource


class GoogleSheetsConnector:
    name = "google_sheets"
    description = "Read/discover Google Sheets through the existing JARVIS data adapter."
    permission = Permission.READ
    requires_confirmation = False
    capabilities = ("list_sheets", "discover_schema", "read_values")

    def __init__(self, source: GoogleSheetsDataSource) -> None:
        self.source = source

    def health(self) -> bool:
        return self.source.client.service is not None

    def invoke(self, operation: str, arguments: Mapping[str, Any]) -> Any:
        if operation == "list_sheets":
            return self.source.discover(str(arguments["spreadsheet_id"]))
        if operation == "discover_schema":
            return self.source.schema(str(arguments["spreadsheet_id"]), str(arguments["sheet_title"]), int(arguments.get("sample_rows", 5)))
        if operation == "read_values":
            return self.source.client.read_values(str(arguments["spreadsheet_id"]), str(arguments["range_name"]), max_rows=arguments.get("max_rows"))
        raise ValueError(f"Unsupported Google Sheets operation: {operation}")
