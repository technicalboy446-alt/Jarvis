from __future__ import annotations

from connectors.google_sheets.client import GoogleSheetsClient
from data.google_sheets.intelligence import SheetIntelligence


class GoogleSheetsDataSource:
    """Adapter between Google Sheets and the canonical JARVIS Data Engine."""
    def __init__(self, client: GoogleSheetsClient):
        self.client = client

    def load_sheet(self, spreadsheet_id: str, sheet_title: str, *, key_fields=()):
        ds = self.client.read_values(spreadsheet_id, f"'{sheet_title}'")
        intelligence = SheetIntelligence()
        ds = intelligence.derive_amount(intelligence.derive_net_quantity(ds))
        from data.validation import validate
        return validate(ds, key_fields=key_fields)

    def discover(self, spreadsheet_id: str):
        return self.client.list_sheets(spreadsheet_id)

    def schema(self, spreadsheet_id: str, sheet_title: str, sample_rows: int = 5):
        return self.client.discover_schema(spreadsheet_id, sheet_title, sample_rows)
