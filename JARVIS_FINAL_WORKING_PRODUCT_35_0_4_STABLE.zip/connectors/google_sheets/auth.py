from __future__ import annotations
from pathlib import Path
from typing import Sequence

SCOPES = ("https://www.googleapis.com/auth/spreadsheets",)

def load_credentials(credentials_path: str | Path, token_path: str | Path, scopes: Sequence[str] = SCOPES):
    """Load or create Google OAuth credentials. Secrets remain outside source control."""
    try:
        from google.oauth2.credentials import Credentials
        from google_auth_oauthlib.flow import InstalledAppFlow
        from google.auth.transport.requests import Request
    except ImportError as exc:
        raise RuntimeError("Google Sheets requires google-auth, google-auth-oauthlib and google-api-python-client") from exc
    credentials_path, token_path = Path(credentials_path), Path(token_path)
    creds = None
    if token_path.exists():
        creds = Credentials.from_authorized_user_file(str(token_path), scopes)
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    if not creds or not creds.valid:
        if not credentials_path.exists():
            raise FileNotFoundError(f"Google OAuth client file not found: {credentials_path}")
        flow = InstalledAppFlow.from_client_secrets_file(str(credentials_path), scopes)
        creds = flow.run_local_server(port=0)
    token_path.parent.mkdir(parents=True, exist_ok=True)
    token_path.write_text(creds.to_json(), encoding="utf-8")
    return creds
