"""Target 19 integration gateway.

Provides one guarded invocation boundary for Google Sheets, messaging,
email, browser, storage and future connectors without replacing their native
adapters.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from core.observability import ObservabilityManager
from security.manager import SecurityManager
from tools.base_tool import Permission
from security.redaction import redact

_SENSITIVE_KEYS = {"api_key", "apikey", "authorization", "password", "token", "secret", "access_token", "refresh_token"}

def _safe_details(value: Any) -> Any:
    if isinstance(value, dict):
        safe = {}
        for key, item in value.items():
            if str(key).strip().lower() in _SENSITIVE_KEYS:
                safe[str(key)] = "[REDACTED]"
            else:
                safe[str(key)] = _safe_details(item)
        return safe
    if isinstance(value, list):
        return [_safe_details(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_safe_details(item) for item in value)
    return redact(value)

from .models import ConnectorResult
from .registry import ConnectorRegistry


@dataclass(frozen=True, slots=True)
class ConnectorCall:
    connector: str
    operation: str
    arguments: dict[str, Any]
    actor: str = "jarvis"
    request_id: str | None = None
    source: str | None = None


class ConnectorGateway:
    """Fail-closed connector execution facade."""

    def __init__(
        self,
        registry: ConnectorRegistry,
        security: SecurityManager,
        observability: ObservabilityManager | None = None,
    ) -> None:
        self.registry = registry
        self.security = security
        self.observability = observability or ObservabilityManager.create()

    def capabilities(self) -> list[dict[str, object]]:
        return self.registry.describe()

    def health(self) -> dict[str, bool]:
        result: dict[str, bool] = {}
        for name in self.registry.names():
            connector = self.registry.get(name)
            try:
                result[name] = bool(connector.health())
            except Exception as exc:
                result[name] = False
                self.observability.emit(
                    "connector_health_failed",
                    status="error",
                    details={"connector": name, "error": str(exc)},
                )
        return result

    def invoke(self, call: ConnectorCall) -> ConnectorResult:
        started = self.observability.metrics.start()
        try:
            connector = self.registry.get(call.connector)
        except Exception as exc:
            self.observability.metrics.finish(started, ok=False)
            self.observability.emit(
                "connector_rejected",
                request_id=call.request_id,
                source=call.source,
                status="error",
                details={"connector": call.connector, "operation": call.operation, "error": str(exc)},
            )
            self.security.audit.record(
                "connector_rejected",
                actor=call.actor,
                result="error",
                details={"request_id": call.request_id, "connector": call.connector, "operation": call.operation, "error": str(exc)},
            )
            return ConnectorResult(False, call.connector, call.operation, error=str(exc))

        decision = self.security.authorize(
            connector.permission,
            requires_confirmation=bool(connector.requires_confirmation),
            actor=call.actor,
        )
        if not decision.allowed:
            self.observability.metrics.finish(started, ok=False)
            self.observability.emit(
                "connector_denied",
                request_id=call.request_id,
                source=call.source,
                status="error",
                details={"connector": connector.name, "operation": call.operation, "reason": decision.reason},
            )
            return ConnectorResult(False, connector.name, call.operation, error=decision.reason)

        self.observability.emit(
            "connector_started",
            request_id=call.request_id,
            source=call.source,
            status="info",
            details={"connector": connector.name, "operation": call.operation},
        )
        try:
            output = connector.invoke(call.operation, dict(call.arguments))
            self.observability.metrics.finish(started, ok=True)
            safe_details = _safe_details({"request_id": call.request_id, "connector": connector.name, "operation": call.operation, "output": output})
            self.security.audit.record("connector_completed", actor=call.actor, result="ok", details=safe_details)
            self.observability.emit(
                "connector_completed",
                request_id=call.request_id,
                source=call.source,
                status="ok",
                details={"connector": connector.name, "operation": call.operation},
            )
            return ConnectorResult(True, connector.name, call.operation, output=output)
        except Exception as exc:
            self.observability.metrics.finish(started, ok=False)
            safe_error = str(_safe_details(str(exc)))
            self.security.audit.record(
                "connector_failed",
                actor=call.actor,
                result="error",
                details={"request_id": call.request_id, "connector": connector.name, "operation": call.operation, "error": safe_error},
            )
            self.observability.emit(
                "connector_failed",
                request_id=call.request_id,
                source=call.source,
                status="error",
                details={"connector": connector.name, "operation": call.operation, "error": safe_error},
            )
            return ConnectorResult(False, connector.name, call.operation, error=safe_error)
