"""Discovery registry for external JARVIS connectors."""
from __future__ import annotations

from typing import Iterable

from .models import Connector


class ConnectorRegistry:
    def __init__(self) -> None:
        self._connectors: dict[str, Connector] = {}

    def register(self, connector: Connector, *, replace: bool = False) -> None:
        name = str(connector.name).strip().lower()
        if not name:
            raise ValueError("Connector name cannot be empty")
        if name in self._connectors and not replace:
            raise ValueError(f"Connector already registered: {connector.name}")
        self._connectors[name] = connector

    def register_many(self, connectors: Iterable[Connector], *, replace: bool = False) -> None:
        for connector in connectors:
            self.register(connector, replace=replace)

    def get(self, name: str) -> Connector:
        key = str(name).strip().lower()
        if key not in self._connectors:
            raise KeyError(f"Unknown JARVIS connector: {name}")
        return self._connectors[key]

    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._connectors))

    def describe(self) -> list[dict[str, object]]:
        return [
            {
                "name": c.name,
                "description": c.description,
                "permission": c.permission.value,
                "requires_confirmation": bool(c.requires_confirmation),
                "capabilities": list(c.capabilities),
            }
            for c in (self._connectors[name] for name in self.names())
        ]
