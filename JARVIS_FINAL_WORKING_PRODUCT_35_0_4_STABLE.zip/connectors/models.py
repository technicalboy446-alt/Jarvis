"""Canonical connector contracts for JARVIS integrations."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol

from tools.base_tool import Permission


@dataclass(frozen=True, slots=True)
class ConnectorResult:
    ok: bool
    connector: str
    operation: str
    output: Any = None
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class Connector(Protocol):
    name: str
    description: str
    permission: Permission
    requires_confirmation: bool
    capabilities: tuple[str, ...]

    def health(self) -> bool: ...
    def invoke(self, operation: str, arguments: Mapping[str, Any]) -> Any: ...
