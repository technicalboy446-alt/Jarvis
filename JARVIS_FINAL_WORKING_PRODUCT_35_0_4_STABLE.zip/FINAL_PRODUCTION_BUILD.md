# JARVIS 35.0.3 — Final Working Production Build

This is the corrected final package produced after auditing the complete available Target lineage.

- Targets reviewed: 0–35
- Primary final baseline: Target 35
- Release: 35.0.3
- Entry point: `main.py`
- Installers: `scripts/install_windows.bat`, `scripts/install_unix.sh`
- Launchers: `scripts/run_windows.bat`, `scripts/run_unix.sh`
- Python: 3.11 / 3.12
- OS: Windows 10/11, macOS, Linux
- PDF generator: intentionally out of current scope
- Primary business focus: Google Sheets/data normalization, deterministic business calculations, filing, reporting, automation, notifications

## Verification

- Full pytest suite: **157 passed**
- Python compileall: **passed**
- No `.pyc` / `.pyo`: **0**
- No shipped credential/private-key files: **0**
- ZIP integrity: **passed**
- Release paths: **passed**
- Bash launcher syntax: **passed**
- Release metadata: **consistent at 35.0.3**

## Known historical limitation

A standalone Target 32 ZIP was not available in the supplied Library chain. The Target 32 contract is present in the final source and its historical validation is preserved in `TARGET_32_STATUS.md`.

## Residual security risks carried by design

- Desktop automation retains its constrained execution facility because that feature depends on generated computer-control actions.
- The remote dashboard is intended for trusted LAN deployment; HTTPS should be preferred whenever certificates are configured.
