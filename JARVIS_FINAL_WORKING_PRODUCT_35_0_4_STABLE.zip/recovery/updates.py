"""Staged update verification without implicit installation."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib
import json
import os
import tempfile
import zipfile

@dataclass(slots=True, frozen=True)
class UpdateManifest:
    version: str
    sha256: str
    archive_name: str

    @classmethod
    def from_dict(cls, data: dict) -> 'UpdateManifest':
        return cls(str(data['version']), str(data['sha256']).lower(), str(data['archive_name']))

@dataclass(slots=True, frozen=True)
class UpdateResult:
    ok: bool
    action: str
    detail: str

class UpdateManager:
    def __init__(self, root: Path | None = None) -> None:
        self.root = (root or Path(__file__).resolve().parents[1]).resolve()
        self.staging = self.root / '.updates'

    @staticmethod
    def sha256(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open('rb') as fh:
            for chunk in iter(lambda: fh.read(1024 * 1024), b''):
                digest.update(chunk)
        return digest.hexdigest()

    def stage(self, archive: Path, manifest: UpdateManifest) -> UpdateResult:
        archive = Path(archive).resolve()
        if not archive.is_file():
            return UpdateResult(False, 'stage', 'archive not found')
        if self.sha256(archive) != manifest.sha256:
            return UpdateResult(False, 'stage', 'sha256 mismatch')
        try:
            with zipfile.ZipFile(archive) as zf:
                bad = zf.testzip()
                if bad:
                    return UpdateResult(False, 'stage', f'corrupt member: {bad}')
            self.staging.mkdir(parents=True, exist_ok=True)
            staged = self.staging / f'{manifest.version}-{manifest.archive_name}'
            staged.write_bytes(archive.read_bytes())
            return UpdateResult(True, 'stage', str(staged))
        except Exception as exc:
            return UpdateResult(False, 'stage', f'{type(exc).__name__}: {exc}')

    def manifest_from_file(self, path: Path) -> UpdateManifest:
        return UpdateManifest.from_dict(json.loads(Path(path).read_text(encoding='utf-8')))
