"""Safe recovery actions; no destructive OS operations."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import shutil

@dataclass(slots=True, frozen=True)
class RecoveryResult:
    action: str
    ok: bool
    detail: str

class RecoveryManager:
    def __init__(self, root: Path | None = None) -> None:
        self.root = (root or Path(__file__).resolve().parents[1]).resolve()

    def ensure_runtime_dirs(self) -> RecoveryResult:
        try:
            for rel in ('config','automation','workspace','reports','logs'):
                (self.root / rel).mkdir(parents=True, exist_ok=True)
            return RecoveryResult('ensure_runtime_dirs', True, 'runtime directories ready')
        except Exception as exc:
            return RecoveryResult('ensure_runtime_dirs', False, f'{type(exc).__name__}: {exc}')

    def quarantine_file(self, path: Path) -> RecoveryResult:
        target = Path(path).resolve()
        try:
            target.relative_to(self.root)
        except ValueError:
            return RecoveryResult('quarantine_file', False, 'path outside JARVIS workspace')
        if not target.is_file():
            return RecoveryResult('quarantine_file', False, 'file not found')
        quarantine = self.root / '.quarantine'
        quarantine.mkdir(exist_ok=True)
        destination = quarantine / target.name
        shutil.move(str(target), str(destination))
        return RecoveryResult('quarantine_file', True, str(destination))
