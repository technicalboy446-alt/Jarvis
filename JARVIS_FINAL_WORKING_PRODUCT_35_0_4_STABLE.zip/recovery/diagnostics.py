"""Deterministic, local diagnostics for JARVIS subsystems."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
import importlib
import shutil
import sys
from pathlib import Path
from typing import Callable

class DiagnosticStatus(str, Enum):
    PASS = 'pass'
    FAIL = 'fail'
    BLOCKED = 'blocked'

@dataclass(slots=True, frozen=True)
class DiagnosticItem:
    name: str
    status: DiagnosticStatus
    detail: str

@dataclass(slots=True, frozen=True)
class DiagnosticReport:
    ok: bool
    items: tuple[DiagnosticItem, ...] = field(default_factory=tuple)

class DiagnosticManager:
    def __init__(self, root: Path | None = None) -> None:
        self.root = (root or Path(__file__).resolve().parents[1]).resolve()
        self._checks: dict[str, Callable[[], DiagnosticItem]] = {}

    def register(self, name: str, check: Callable[[], DiagnosticItem]) -> None:
        key = str(name).strip()
        if not key or not callable(check):
            raise ValueError('Diagnostic checks require a non-empty name and callable.')
        self._checks[key] = check

    def register_import(self, module_name: str, *, optional: bool = False) -> None:
        def check() -> DiagnosticItem:
            try:
                importlib.import_module(module_name)
                return DiagnosticItem(module_name, DiagnosticStatus.PASS, 'import ok')
            except Exception as exc:
                status = DiagnosticStatus.BLOCKED if optional and isinstance(exc, ModuleNotFoundError) else DiagnosticStatus.FAIL
                return DiagnosticItem(module_name, status, f'{type(exc).__name__}: {exc}')
        self.register(f'import:{module_name}', check)

    def register_path(self, path: Path, name: str | None = None) -> None:
        target = Path(path)
        label = name or f'path:{target}'
        def check() -> DiagnosticItem:
            ok = target.exists()
            return DiagnosticItem(label, DiagnosticStatus.PASS if ok else DiagnosticStatus.FAIL,
                                  'exists' if ok else 'missing')
        self.register(label, check)

    def register_disk(self, path: Path | None = None, min_free_bytes: int = 50 * 1024 * 1024) -> None:
        target = Path(path or self.root)
        def check() -> DiagnosticItem:
            try:
                free = shutil.disk_usage(target).free
                ok = free >= min_free_bytes
                return DiagnosticItem('disk_free', DiagnosticStatus.PASS if ok else DiagnosticStatus.FAIL,
                                      f'{free} bytes free')
            except Exception as exc:
                return DiagnosticItem('disk_free', DiagnosticStatus.FAIL, f'{type(exc).__name__}: {exc}')
        self.register('disk_free', check)

    def run(self) -> DiagnosticReport:
        items: list[DiagnosticItem] = []
        for check in self._checks.values():
            try:
                items.append(check())
            except Exception as exc:
                items.append(DiagnosticItem('internal', DiagnosticStatus.FAIL, f'{type(exc).__name__}: {exc}'))
        ok = all(i.status != DiagnosticStatus.FAIL for i in items)
        return DiagnosticReport(ok=ok, items=tuple(items))

    @classmethod
    def standard(cls, root: Path | None = None) -> 'DiagnosticManager':
        mgr = cls(root)
        for module in ('core.assistant.bootstrap','core.configuration.config_manager','core.routing.router','core.orchestration.orchestrator'):
            mgr.register_import(module)
        mgr.register_import('interface.desktop.ui', optional=True)
        mgr.register_path(mgr.root / 'config', 'config_dir')
        mgr.register_path(mgr.root / 'automation', 'automation_dir')
        mgr.register_disk()
        return mgr
