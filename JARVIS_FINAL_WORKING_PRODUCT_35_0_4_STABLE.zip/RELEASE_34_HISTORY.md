# Target 34 — Release & Deployment Packaging

## Release
- JARVIS release line: `34.0.0`
- Baseline: locked Target 33
- Distribution: source release with reproducible install/launch entry points

## Included
- Full application source and existing regression tests
- `requirements.txt` dependency contract
- `.env.example` configuration template
- Windows and POSIX installer/launcher scripts
- Release manifest and deployment documentation
- Clean package with no Python bytecode or runtime secrets

## Deployment policy
1. Create a dedicated virtual environment.
2. Install from `requirements.txt`.
3. Install Playwright Chromium only when browser automation is needed.
4. Keep `config/api_keys.json` local and never ship it in a release archive.
5. Launch through the provided platform script.

## Validation
- Python compilation: required for all shipped `.py` files.
- ZIP integrity: required.
- `.pyc`/`.pyo` scan: zero.
- Runtime secret-file scan: zero shipped credential files.
