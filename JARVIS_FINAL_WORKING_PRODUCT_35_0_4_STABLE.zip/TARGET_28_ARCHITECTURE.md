# JARVIS Target 28 — Dashboard & Remote Operations Expansion

## Scope
Target 28 expands the existing authenticated dashboard into a bounded remote operations surface. It does not replace the existing dashboard server, websocket, upload, command queue, automation engine, reporting pipeline, security layer, or orchestration.

## New capabilities
- authenticated remote overview
- authenticated report listing with period filtering
- authenticated automation job listing
- authenticated recent automation-run listing
- authenticated health checks
- authenticated remote command queue endpoint
- bounded workspace-relative file views
- fail-closed workspace path containment

## Request flow
Browser / phone
→ dashboard authentication token
→ Target 28 remote API
→ bounded read facade or existing command queue
→ existing JARVIS runtime

## Security boundary
Read endpoints require an existing authenticated dashboard token. Commands remain on the existing command queue path; Target 16/24 security continues to govern downstream execution.

## No new privileged filesystem API
The remote facade only returns metadata for files under the JARVIS workspace and rejects path traversal.
