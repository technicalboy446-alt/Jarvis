"""Target 27 bilingual report presentation helpers.

The core report builders remain language-neutral. This module creates a stable
English/Arabic presentation without requiring a model call; applications can
provide a translator callback for arbitrary labels/content when needed.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Any, Callable

from reports.models.report_models import Report

AR_LABELS = {
    "date": "التاريخ",
    "trip_id": "رقم الرحلة",
    "vehicle_id": "المركبة",
    "driver": "السائق",
    "material_id": "المادة",
    "quantity": "الكمية",
    "unit_price": "سعر الوحدة",
    "amount": "المبلغ",
    "expense_id": "رقم المصروف",
    "category": "الفئة",
    "company_id": "الشركة",
    "description": "الوصف",
    "payment_id": "رقم السداد",
    "invoice_id": "رقم الفاتورة",
    "reference": "المرجع",
    "metric": "المؤشر",
    "value": "القيمة",
}


def _safe_value(value: Any) -> Any:
    if isinstance(value, Decimal):
        return str(value)
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return value


def bilingual_name(name: str) -> str:
    names = {
        "Trip Report": "تقرير الرحلات",
        "Expense Report": "تقرير المصروفات",
        "Payment Report": "تقرير السداد",
        "Management Summary": "ملخص الإدارة",
    }
    return f"{name} / {names.get(name, name)}"


def bilingual_report(report: Report, translator: Callable[[str, str], str] | None = None) -> dict[str, Any]:
    """Return a serialisable EN/AR combined representation.

    `translator(text, target_language)` can be supplied when business-specific
    labels or free text require richer Arabic. Missing translations safely fall
    back to the original English text.
    """
    def translate(text: str) -> str:
        if translator is not None:
            try:
                translated = translator(text, "ar")
                if translated:
                    return str(translated)
            except Exception:
                pass
        return AR_LABELS.get(text, text)

    columns = [
        {"key": c, "en": c, "ar": translate(c)}
        for c in report.columns
    ]
    rows = []
    for row in report.rows:
        rows.append({
            key: {"en": _safe_value(value), "ar": _safe_value(value)}
            for key, value in row.values.items()
        })

    summary = {
        key: {"en": _safe_value(value), "ar": _safe_value(value)}
        for key, value in report.summary.items()
    }
    return {
        "name": {"en": report.name, "ar": bilingual_name(report.name)},
        "period": {
            "start": report.period_start.isoformat(),
            "end": report.period_end.isoformat(),
        },
        "columns": columns,
        "rows": rows,
        "summary": summary,
    }
