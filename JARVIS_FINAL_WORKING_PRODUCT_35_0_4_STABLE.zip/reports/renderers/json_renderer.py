import json
from pathlib import Path
from decimal import Decimal
from dataclasses import asdict
from reports.models.report_models import Report


def _default(value):
    if isinstance(value, Decimal): return str(value)
    return value.isoformat() if hasattr(value, "isoformat") else str(value)


def render_json(report: Report, output_path: str) -> str:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "name": report.name, "period_start": report.period_start, "period_end": report.period_end,
        "columns": report.columns, "rows": [asdict(r) for r in report.rows], "summary": report.summary,
    }
    path.write_text(json.dumps(payload, default=_default, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(path)
