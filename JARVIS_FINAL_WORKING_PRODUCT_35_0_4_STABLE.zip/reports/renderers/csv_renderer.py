import csv
from pathlib import Path
from reports.models.report_models import Report


def render_csv(report: Report, output_path: str) -> str:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=report.columns)
        writer.writeheader()
        for row in report.rows:
            writer.writerow(row.values)
    return str(path)
