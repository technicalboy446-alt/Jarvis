"""Target 27 report pipeline and daily/weekly/monthly filing helpers."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
import json
from pathlib import Path
from typing import Any, Sequence

from business.models.domain_models import Expense, Payment, Trip
from reports.builders.business_reports import (
    expense_report,
    management_summary,
    payment_report,
    trip_report,
)
from reports.bilingual import bilingual_report


@dataclass(frozen=True)
class ReportBundle:
    english_json: Path
    bilingual_json: Path
    english_csv: Path
    bilingual_csv: Path


class ReportPipeline:
    """Generate deterministic reports and keep them in an organised hierarchy."""

    def __init__(self, root: str | Path = "workspace/reports") -> None:
        self.root = Path(root)

    def _period_dir(self, period: str, end: date) -> Path:
        path = self.root / period / f"{end:%Y-%m}"
        path.mkdir(parents=True, exist_ok=True)
        return path

    @staticmethod
    def period(kind: str, anchor: date) -> tuple[date, date]:
        k = kind.lower().strip()
        if k == "daily":
            return anchor, anchor
        if k == "weekly":
            start = anchor - timedelta(days=anchor.weekday())
            return start, start + timedelta(days=6)
        if k == "monthly":
            start = anchor.replace(day=1)
            if start.month == 12:
                next_start = start.replace(year=start.year + 1, month=1)
            else:
                next_start = start.replace(month=start.month + 1)
            return start, next_start - timedelta(days=1)
        raise ValueError(f"Unsupported report period: {kind}")

    def build_management(
        self,
        *,
        kind: str,
        anchor: date,
        trips: Sequence[Trip],
        expenses: Sequence[Expense],
        payments: Sequence[Payment],
        invoiced_amount=0,
    ):
        start, end = self.period(kind, anchor)
        return management_summary(trips, expenses, payments, start, end, invoiced_amount)

    def write_management(
        self,
        *,
        kind: str,
        anchor: date,
        trips: Sequence[Trip],
        expenses: Sequence[Expense],
        payments: Sequence[Payment],
        invoiced_amount=0,
    ) -> ReportBundle:
        report = self.build_management(
            kind=kind,
            anchor=anchor,
            trips=trips,
            expenses=expenses,
            payments=payments,
            invoiced_amount=invoiced_amount,
        )
        folder = self._period_dir(kind, report.period_end)
        stem = f"management_{report.period_start}_{report.period_end}"
        en_json = folder / f"{stem}.json"
        bi_json = folder / f"{stem}_en_ar.json"
        en_csv = folder / f"{stem}.csv"
        bi_csv = folder / f"{stem}_en_ar.csv"

        en_payload = {
            "name": report.name,
            "period_start": report.period_start.isoformat(),
            "period_end": report.period_end.isoformat(),
            "columns": report.columns,
            "rows": [row.values for row in report.rows],
            "summary": report.summary,
        }
        en_json.write_text(json.dumps(en_payload, ensure_ascii=False, default=str, indent=2), encoding="utf-8")
        bi_json.write_text(json.dumps(bilingual_report(report), ensure_ascii=False, indent=2), encoding="utf-8")

        headers = ["metric", "value"]
        with en_csv.open("w", encoding="utf-8-sig") as f:
            f.write(",".join(headers) + "\n")
            for row in report.rows:
                f.write(f"{row.values.get('metric','')},{row.values.get('value','')}\n")

        with bi_csv.open("w", encoding="utf-8-sig") as f:
            f.write("metric_en,metric_ar,value_en,value_ar\n")
            for key, item in report.summary.items():
                label_ar = bilingual_report(report)["summary"][key]
                f.write(f"{key},{key},{item},{label_ar['ar']}\n")

        return ReportBundle(en_json, bi_json, en_csv, bi_csv)
