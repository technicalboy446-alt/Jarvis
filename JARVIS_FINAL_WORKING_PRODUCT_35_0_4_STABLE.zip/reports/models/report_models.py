from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any, Dict, List

@dataclass(frozen=True)
class ReportRow:
    values: Dict[str, Any]

@dataclass(frozen=True)
class Report:
    name: str
    period_start: date
    period_end: date
    columns: List[str]
    rows: List[ReportRow]
    summary: Dict[str, Any] = field(default_factory=dict)
