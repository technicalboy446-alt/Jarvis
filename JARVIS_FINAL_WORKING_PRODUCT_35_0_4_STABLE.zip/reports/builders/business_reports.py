from datetime import date
from decimal import Decimal
from typing import Iterable, Sequence

from business.models.domain_models import Expense, Payment, Trip
from reports.models.report_models import Report, ReportRow


def _in_period(d: date, start: date, end: date) -> bool:
    return start <= d <= end


def trip_report(trips: Iterable[Trip], start: date, end: date) -> Report:
    selected = [t for t in trips if _in_period(t.trip_date, start, end)]
    rows = [ReportRow({
        "date": t.trip_date.isoformat(), "trip_id": t.id, "vehicle_id": t.vehicle_id,
        "driver": t.driver, "material_id": t.material_id or "", "quantity": t.net_weight or Decimal("0"),
        "unit_price": t.unit_price if t.unit_price is not None else "", "amount": t.amount if t.amount is not None else "",
    }) for t in selected]
    total_qty = sum((t.net_weight or Decimal("0") for t in selected), Decimal("0"))
    total_amount = sum((t.amount or Decimal("0") for t in selected), Decimal("0"))
    return Report("Trip Report", start, end, ["date","trip_id","vehicle_id","driver","material_id","quantity","unit_price","amount"], rows,
                  {"trip_count": len(selected), "total_quantity": total_qty, "total_amount": total_amount})


def expense_report(expenses: Iterable[Expense], start: date, end: date) -> Report:
    selected = [e for e in expenses if _in_period(e.expense_date, start, end)]
    rows = [ReportRow({"date": e.expense_date.isoformat(), "expense_id": e.id, "category": e.category, "company_id": e.company_id or "", "amount": e.amount, "description": e.description}) for e in selected]
    total = sum((e.amount for e in selected), Decimal("0"))
    return Report("Expense Report", start, end, ["date","expense_id","category","company_id","amount","description"], rows, {"expense_total": total, "expense_count": len(selected)})


def payment_report(payments: Iterable[Payment], start: date, end: date, invoiced_amount: Decimal = Decimal("0")) -> Report:
    selected = [p for p in payments if _in_period(p.payment_date, start, end)]
    rows = [ReportRow({"date": p.payment_date.isoformat(), "payment_id": p.id, "company_id": p.company_id or "", "invoice_id": p.invoice_id or "", "amount": p.amount, "reference": p.reference}) for p in selected]
    paid = sum((p.amount for p in payments), Decimal("0"))
    return Report("Payment Report", start, end, ["date","payment_id","company_id","invoice_id","amount","reference"], rows,
                  {"period_payment_total": sum((p.amount for p in selected), Decimal("0")), "lifetime_paid": paid, "outstanding": Decimal(invoiced_amount) - paid})


def management_summary(trips: Sequence[Trip], expenses: Sequence[Expense], payments: Sequence[Payment], start: date, end: date, invoiced_amount: Decimal = Decimal("0")) -> Report:
    tr = trip_report(trips, start, end); ex = expense_report(expenses, start, end); pa = payment_report(payments, start, end, invoiced_amount)
    summary = {**tr.summary, **ex.summary, **pa.summary, "net_after_expenses": tr.summary["total_amount"] - ex.summary["expense_total"]}
    return Report("Management Summary", start, end, ["metric", "value"], [ReportRow({"metric": k, "value": v}) for k, v in summary.items()], summary)
