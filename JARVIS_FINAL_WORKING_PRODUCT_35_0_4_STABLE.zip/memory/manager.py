from pathlib import Path
from .interface import JarvisMemory
from .types import MemoryScope

BASE_DIR=Path(__file__).resolve().parent.parent
DEFAULT_PATH=BASE_DIR/'workspace'/'memory'/'jarvis_memory.json'

_memory=JarvisMemory(DEFAULT_PATH)

def get_memory() -> JarvisMemory:
    return _memory

def remember(key, value, scope=MemoryScope.LONG_TERM, **kwargs):
    return _memory.remember(key, value, scope, **kwargs)

def recall(key, scope=MemoryScope.LONG_TERM):
    return _memory.recall(key, scope)

def search(query, scopes=None, limit=20):
    return _memory.search(query, scopes, limit)

def forget(key, scope=MemoryScope.LONG_TERM):
    return _memory.forget(key, scope)
