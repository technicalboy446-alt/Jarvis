from __future__ import annotations
from dataclasses import replace
from datetime import datetime, timezone
from typing import Iterable
import math

from .types import MemoryRecord, MemoryScope


class MemoryIntelligence:
    """Small deterministic policy layer over the existing JarvisMemory store."""

    def __init__(self, memory):
        self.memory = memory

    @staticmethod
    def _now() -> datetime:
        return datetime.now(timezone.utc)

    @classmethod
    def is_expired(cls, record: MemoryRecord, now: datetime | None = None) -> bool:
        if record.ttl_seconds is None:
            return False
        now = now or cls._now()
        try:
            updated = datetime.fromisoformat(record.updated_at.replace("Z", "+00:00"))
        except Exception:
            return True
        return (now - updated).total_seconds() >= max(0, record.ttl_seconds)

    @classmethod
    def recency_score(cls, record: MemoryRecord, now: datetime | None = None) -> float:
        now = now or cls._now()
        try:
            updated = datetime.fromisoformat(record.updated_at.replace("Z", "+00:00"))
            age_hours = max(0.0, (now - updated).total_seconds() / 3600.0)
        except Exception:
            age_hours = 10_000.0
        return math.exp(-age_hours / 168.0)  # one-week half-life-ish decay

    def ranked_search(
        self,
        query: str,
        scopes: Iterable[MemoryScope] | None = None,
        limit: int = 20,
        include_expired: bool = False,
    ) -> list[MemoryRecord]:
        records = list(self.memory.search(query, scopes=scopes, limit=max(limit * 3, limit)))
        now = self._now()
        scored: list[tuple[float, MemoryRecord]] = []
        q = query.lower().strip()
        for record in records:
            if not include_expired and self.is_expired(record, now):
                continue
            text = f"{record.key} {record.value} {' '.join(record.tags)}".lower()
            lexical = 1.0 if q and q in text else 0.0
            score = (record.importance * 0.45) + (self.recency_score(record, now) * 0.35) + (lexical * 0.20)
            scored.append((score, record))
        scored.sort(key=lambda item: (item[0], item[1].updated_at), reverse=True)
        return [record for _, record in scored[:limit]]

    def purge_expired(self) -> int:
        removed = 0
        for scope in MemoryScope:
            for record in list(self.memory.search("", scopes=[scope], limit=10000)):
                if self.is_expired(record):
                    self.memory.forget(record.key, record.scope)
                    removed += 1
        return removed

    def build_context(self, query: str, limit: int = 8, max_chars: int = 6000) -> str:
        rows: list[str] = []
        used = 0
        for record in self.ranked_search(query, limit=limit):
            value = str(record.value).replace("\x00", " ").strip()
            if record.sensitive:
                value = "[sensitive memory omitted]"
            line = f"[{record.scope.value}] {record.key}: {value}"
            if used + len(line) + 1 > max_chars:
                break
            rows.append(line)
            used += len(line) + 1
        return "\n".join(rows)
