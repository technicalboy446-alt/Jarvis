from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

class MemoryScope(str, Enum):
    SHORT_TERM = 'short_term'
    BUSINESS = 'business'
    PREFERENCE = 'preference'
    LONG_TERM = 'long_term'

@dataclass(frozen=True)
class MemoryRecord:
    key: str
    value: Any
    scope: MemoryScope
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    source: str = 'jarvis'
    tags: tuple[str, ...] = ()
    importance: int = 1
    ttl_seconds: int | None = None
    sensitive: bool = False
