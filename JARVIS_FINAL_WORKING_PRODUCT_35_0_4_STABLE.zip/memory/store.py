import json, time
from pathlib import Path
from threading import RLock
from .types import MemoryRecord, MemoryScope

class MemoryStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.lock = RLock()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict:
        if not self.path.exists():
            return {scope.value: {} for scope in MemoryScope}
        try:
            data = json.loads(self.path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            data = {}
        base = {scope.value: {} for scope in MemoryScope}
        for scope in base:
            if isinstance(data.get(scope), dict):
                base[scope] = data[scope]
        return base

    def _save(self, data: dict) -> None:
        tmp = self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(self.path)

    def put(self, record: MemoryRecord) -> None:
        if record.scope is MemoryScope.SHORT_TERM and record.ttl_seconds is None:
            raise ValueError('short_term memory requires ttl_seconds')
        payload = {
            'value': record.value,
            'updated_at': record.updated_at,
            'source': record.source,
            'tags': list(record.tags),
            'importance': max(1, min(5, int(record.importance))),
            'ttl_seconds': record.ttl_seconds,
            'sensitive': bool(record.sensitive),
        }
        with self.lock:
            data = self._load()
            data[record.scope.value][record.key] = payload
            self._save(data)

    def get(self, scope: MemoryScope, key: str) -> MemoryRecord | None:
        with self.lock:
            data = self._load()
        raw = data.get(scope.value, {}).get(key)
        if not isinstance(raw, dict):
            return None
        ttl = raw.get('ttl_seconds')
        updated = raw.get('updated_at', '')
        if ttl is not None and updated:
            try:
                from datetime import datetime
                age = time.time() - datetime.fromisoformat(updated).timestamp()
                if age > int(ttl):
                    self.delete(scope, key)
                    return None
            except Exception:
                pass
        return MemoryRecord(key=key, value=raw.get('value'), scope=scope, updated_at=updated,
                            source=raw.get('source','jarvis'), tags=tuple(raw.get('tags',[])),
                            importance=int(raw.get('importance',1)), ttl_seconds=ttl,
                            sensitive=bool(raw.get('sensitive',False)))

    def search(self, query: str, scopes: tuple[MemoryScope, ...] | None = None, limit: int = 20) -> list[MemoryRecord]:
        scopes = scopes or tuple(MemoryScope)
        q = query.casefold().strip()
        results=[]
        with self.lock:
            data=self._load()
        for scope in scopes:
            for key, raw in data.get(scope.value, {}).items():
                hay=' '.join([key, str(raw.get('value','')), ' '.join(raw.get('tags',[]))]).casefold()
                if q and q not in hay:
                    continue
                rec=self.get(scope,key)
                if rec: results.append(rec)
        results.sort(key=lambda r:(r.importance, r.updated_at), reverse=True)
        return results[:limit]

    def delete(self, scope: MemoryScope, key: str) -> None:
        with self.lock:
            data=self._load()
            data.get(scope.value, {}).pop(key, None)
            self._save(data)
