from pathlib import Path
from .store import MemoryStore
from .types import MemoryRecord, MemoryScope

class JarvisMemory:
    def __init__(self, path: Path):
        self.store=MemoryStore(path)

    def remember(self, key, value, scope=MemoryScope.LONG_TERM, **kwargs):
        record=MemoryRecord(key=key, value=value, scope=MemoryScope(scope), **kwargs)
        self.store.put(record)
        return record

    def recall(self, key, scope=MemoryScope.LONG_TERM):
        return self.store.get(MemoryScope(scope), key)

    def search(self, query, scopes=None, limit=20):
        return self.store.search(query, scopes, limit)

    def forget(self, key, scope=MemoryScope.LONG_TERM):
        self.store.delete(MemoryScope(scope), key)
