# Target 24 Security Architecture

SecurityManager now exposes `authorize_actor(actor, permission, ...)`.
RBAC is evaluated before the existing SecurityPolicy. All decisions are audited.

Target 16 remains authoritative for destructive/admin confirmation and filesystem guards.
