# TARGET 30 — Self-Diagnostics, Recovery & Update Management

## Scope
Target 30 adds a safe operational layer for diagnosing JARVIS locally, applying non-destructive recovery actions, and staging verified updates without implicit installation.

## Components
- `recovery/diagnostics.py` — deterministic import, path, and disk probes.
- `recovery/recovery.py` — bounded recovery actions and workspace quarantine.
- `recovery/updates.py` — SHA-256 verification, ZIP integrity validation, and staged update storage.

## Safety rules
1. Diagnostics are local by default and do not contact external services.
2. Recovery is workspace-scoped and does not run destructive OS commands.
3. Quarantine refuses paths outside the JARVIS workspace.
4. Updates are staged only after checksum and archive validation.
5. Update staging never auto-installs or overwrites the active application.
6. Existing Target 16 security, Target 20 automation, Target 24 RBAC, and Target 29 notifications remain authoritative.

## Flow
```text
JARVIS / Scheduler / Dashboard
          ↓
   Diagnostics Manager
          ↓
  Health / Failure State
      ↙          ↘
Recovery       Update Manager
   ↓                ↓
Safe Actions     Verified Staging
```
