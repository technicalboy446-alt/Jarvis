"""JARVIS dashboard package."""
