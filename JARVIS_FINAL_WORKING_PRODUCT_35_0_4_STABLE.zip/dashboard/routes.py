from __future__ import annotations
from .api import dashboard_snapshot, workspace_stats, automation_stats, system_status

def snapshot() -> dict:
    return dashboard_snapshot()

def workspace() -> dict:
    return workspace_stats()

def automation() -> dict:
    return automation_stats()

def system() -> dict:
    return system_status()

# Target 28 remote routes

def remote_overview() -> dict:
    from .api import remote_overview as _remote_overview
    return _remote_overview()


def reports(period: str | None = None, limit: int = 100) -> list[dict]:
    from .api import remote_reports
    return remote_reports(period, limit)


def jobs() -> list[dict]:
    from .api import remote_jobs
    return remote_jobs()


def runs(limit: int = 50) -> list[dict]:
    from .api import remote_runs
    return remote_runs(limit)


def health() -> dict:
    from .api import remote_health
    return remote_health()
