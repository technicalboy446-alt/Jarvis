from __future__ import annotations
from pathlib import Path
from typing import Any, Iterable
import json

BASE_DIR = Path(__file__).resolve().parent.parent
WORKSPACE = BASE_DIR / "workspace"
REPORTS = WORKSPACE / "reports"
ARCHIVES = WORKSPACE / "archives"
INCOMING = WORKSPACE / "incoming"
PROCESSED = WORKSPACE / "processed"
STATEMENTS = WORKSPACE / "statements"

def _count_files(path: Path) -> int:
    return sum(1 for p in path.rglob("*") if p.is_file()) if path.exists() else 0

def workspace_stats() -> dict[str, Any]:
    return {
        "incoming": _count_files(INCOMING),
        "processed": _count_files(PROCESSED),
        "reports": _count_files(REPORTS),
        "statements": _count_files(STATEMENTS),
        "archives": _count_files(ARCHIVES),
    }

def automation_stats() -> dict[str, Any]:
    jobs = Path(BASE_DIR / "automation" / "jobs.json")
    runs = Path(BASE_DIR / "automation" / "runs.jsonl")
    job_count = 0
    run_count = 0
    try:
        data = json.loads(jobs.read_text(encoding="utf-8")) if jobs.exists() else []
        job_count = len(data) if isinstance(data, list) else len(data.get("jobs", []))
    except Exception:
        pass
    if runs.exists():
        try:
            run_count = sum(1 for line in runs.read_text(encoding="utf-8").splitlines() if line.strip())
        except Exception:
            pass
    return {"jobs": job_count, "runs": run_count}

def system_status() -> dict[str, Any]:
    return {
        "workspace": WORKSPACE.exists(),
        "reports": REPORTS.exists(),
        "automation": (BASE_DIR / "automation").exists(),
        "google_sheets_connector": (BASE_DIR / "connectors" / "google_sheets").exists(),
    }

def dashboard_snapshot() -> dict[str, Any]:
    return {
        "workspace": workspace_stats(),
        "automation": automation_stats(),
        "system": system_status(),
    }

# Target 28 remote operations -------------------------------------------------
def remote_overview() -> dict[str, Any]:
    from .remote import RemoteDashboardService
    return RemoteDashboardService(BASE_DIR).overview()


def remote_reports(period: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
    from .remote import RemoteDashboardService
    return RemoteDashboardService(BASE_DIR).reports_list(period, limit=limit)


def remote_jobs() -> list[dict[str, Any]]:
    from .remote import RemoteDashboardService
    return RemoteDashboardService(BASE_DIR).jobs()


def remote_runs(limit: int = 50) -> list[dict[str, Any]]:
    from .remote import RemoteDashboardService
    return RemoteDashboardService(BASE_DIR).runs(limit=limit)


def remote_health() -> dict[str, Any]:
    from .remote import RemoteDashboardService
    return RemoteDashboardService(BASE_DIR).health()
