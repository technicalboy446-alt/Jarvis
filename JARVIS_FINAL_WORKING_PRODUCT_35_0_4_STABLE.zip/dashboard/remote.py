"""Target 28 remote dashboard operations facade.

Read-heavy, deterministic remote views over workspace/report/automation state.
The facade never exposes arbitrary filesystem paths and keeps the dashboard
server's existing command queue as the write/command channel.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import json

from automation.store import AutomationStore


@dataclass(frozen=True)
class RemoteDashboardService:
    base_dir: Path

    @property
    def workspace(self) -> Path:
        return self.base_dir / "workspace"

    @property
    def reports(self) -> Path:
        return self.workspace / "reports"

    @property
    def automation(self) -> Path:
        return self.base_dir / "automation"

    @staticmethod
    def _count_files(path: Path) -> int:
        return sum(1 for item in path.rglob("*") if item.is_file()) if path.exists() else 0

    def _safe_workspace_path(self, relative: str = "") -> Path:
        candidate = (self.workspace / relative).resolve()
        root = self.workspace.resolve()
        if candidate != root and root not in candidate.parents:
            raise ValueError("Workspace path escapes the JARVIS workspace.")
        return candidate

    @staticmethod
    def _file_info(path: Path, root: Path) -> dict[str, Any]:
        stat = path.stat()
        return {
            "name": path.name,
            "path": str(path.resolve().relative_to(root.resolve())).replace("\\", "/"),
            "size": stat.st_size,
            "modified": stat.st_mtime,
            "suffix": path.suffix.lower(),
        }

    def overview(self) -> dict[str, Any]:
        reports = self._count_files(self.reports)
        incoming = self._count_files(self.workspace / "incoming")
        processed = self._count_files(self.workspace / "processed")
        statements = self._count_files(self.workspace / "statements")
        archives = self._count_files(self.workspace / "archives")
        jobs = self._list_jobs()
        runs = self._list_runs(limit=25)
        return {
            "workspace": {
                "incoming": incoming,
                "processed": processed,
                "reports": reports,
                "statements": statements,
                "archives": archives,
            },
            "automation": {
                "jobs": len(jobs),
                "recent_runs": len(runs),
            },
            "system": {
                "workspace": self.workspace.exists(),
                "reports": self.reports.exists(),
                "automation": self.automation.exists(),
                "google_sheets_connector": (self.base_dir / "connectors" / "google_sheets").exists(),
                "dashboard": (self.base_dir / "dashboard").exists(),
            },
        }

    def workspace_files(self, relative: str = "", *, limit: int = 100) -> list[dict[str, Any]]:
        root = self._safe_workspace_path(relative)
        if not root.exists():
            return []
        files = [p for p in root.rglob("*") if p.is_file()]
        files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return [self._file_info(p, self.workspace) for p in files[: max(1, min(limit, 500))]]

    def reports_list(self, period: str | None = None, *, limit: int = 100) -> list[dict[str, Any]]:
        relative = "reports"
        if period:
            safe = str(period).strip().replace("..", "")
            if "/" in safe or "\\" in safe:
                raise ValueError("Invalid report period.")
            relative = f"reports/{safe}"
        return self.workspace_files(relative, limit=limit)

    def _list_jobs(self) -> list[dict[str, Any]]:
        try:
            store = AutomationStore(self.automation)
            return [j.to_dict() for j in store.list_jobs()]
        except Exception:
            return []

    def jobs(self) -> list[dict[str, Any]]:
        return self._list_jobs()

    def _list_runs(self, *, limit: int = 50) -> list[dict[str, Any]]:
        path = self.automation / "runs.jsonl"
        if not path.exists():
            return []
        rows: list[dict[str, Any]] = []
        try:
            for line in path.read_text(encoding="utf-8").splitlines()[-max(1, min(limit, 500)) :]:
                if line.strip():
                    try:
                        rows.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        except Exception:
            return []
        return list(reversed(rows))

    def runs(self, *, limit: int = 50) -> list[dict[str, Any]]:
        return self._list_runs(limit=limit)

    def health(self) -> dict[str, Any]:
        checks = {
            "dashboard": (self.base_dir / "dashboard").exists(),
            "workspace": self.workspace.exists(),
            "reports": self.reports.exists(),
            "automation": self.automation.exists(),
            "google_sheets": (self.base_dir / "connectors" / "google_sheets").exists(),
            "security": (self.base_dir / "security").exists(),
            "observability": (self.base_dir / "core" / "observability").exists(),
        }
        ok = all(checks.values())
        return {"ok": ok, "checks": checks}
