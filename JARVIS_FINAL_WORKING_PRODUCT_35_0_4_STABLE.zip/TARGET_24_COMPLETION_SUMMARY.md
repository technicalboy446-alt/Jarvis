# Target 24 — Policy, Permission & Role Management

Adds role-aware authorization without replacing the Target 16 fail-closed security policy.

Roles: viewer, operator, admin.

Unknown actors default to operator, preserving existing read/write behavior while preventing admin access.
