from __future__ import annotations
import json
from pathlib import Path
from typing import Any

class NotificationStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._data: dict[str, Any] = {"sent": {}, "history": []}
        self._load()
    def _load(self) -> None:
        try:
            if self.path.exists():
                obj = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(obj, dict):
                    self._data.update(obj)
        except Exception:
            self._data = {"sent": {}, "history": []}
    def _save(self) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(self._data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)
    def sent(self, notification_id: str) -> dict[str, Any] | None:
        value = self._data.get("sent", {}).get(notification_id)
        return value if isinstance(value, dict) else None
    def record(self, notification_id: str, result: dict[str, Any]) -> None:
        self._data.setdefault("sent", {})[notification_id] = result
        self._data.setdefault("history", []).append(result)
        self._save()
    def history(self, limit: int = 100) -> list[dict[str, Any]]:
        return list(self._data.get("history", []))[-limit:]
