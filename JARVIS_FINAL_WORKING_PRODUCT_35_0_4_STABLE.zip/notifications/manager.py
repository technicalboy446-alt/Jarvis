from __future__ import annotations
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Mapping
from notifications.adapters import NotificationAdapter
from notifications.models import NotificationRequest, NotificationResult
from notifications.store import NotificationStore
from security.manager import SecurityManager
from tools.base_tool import Permission

class NotificationManager:
    def __init__(self, root: str | Path, *, security: SecurityManager | None = None, store: NotificationStore | None = None, max_attempts: int = 3, backoff_seconds: float = 0.05) -> None:
        root = Path(root)
        self.security = security
        self.store = store or NotificationStore(root / "notifications" / "history.json")
        self.adapters: dict[str, NotificationAdapter] = {}
        self.max_attempts = max(1, int(max_attempts))
        self.backoff_seconds = max(0.0, float(backoff_seconds))
    def register(self, adapter: NotificationAdapter) -> None:
        self.adapters[adapter.channel] = adapter
    def available_channels(self) -> list[str]:
        return sorted(self.adapters)
    def send(self, request: NotificationRequest) -> NotificationResult:
        prior = self.store.sent(request.notification_id)
        if prior and prior.get("status") == "sent":
            return NotificationResult(True, request.notification_id, request.channel, request.recipient, "deduplicated", int(prior.get("attempts", 0)), "Already sent.", prior.get("provider_id"), prior.get("created_at", ""))
        if self.security is not None:
            decision = self.security.authorize_actor(request.actor, Permission.WRITE)
            if not decision.allowed:
                result = NotificationResult(False, request.notification_id, request.channel, request.recipient, "denied", 0, decision.reason)
                self.store.record(request.notification_id, asdict(result))
                return result
        adapter = self.adapters.get(request.channel)
        if adapter is None:
            result = NotificationResult(False, request.notification_id, request.channel, request.recipient, "unsupported", 0, f"Unsupported notification channel: {request.channel}")
            self.store.record(request.notification_id, asdict(result))
            return result
        last_error = ""
        for attempt in range(1, self.max_attempts + 1):
            try:
                provider_id = adapter.send(request.recipient, subject=request.subject, text=request.text, metadata=request.metadata)
                result = NotificationResult(True, request.notification_id, request.channel, request.recipient, "sent", attempt, "Delivered.", provider_id)
                self.store.record(request.notification_id, asdict(result))
                if self.security is not None:
                    self.security.audit.record("notification_sent", actor=request.actor, result="ok", details={"notification_id": request.notification_id, "channel": request.channel, "recipient": request.recipient, "attempts": attempt})
                return result
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                if attempt < self.max_attempts:
                    time.sleep(self.backoff_seconds * (2 ** (attempt - 1)))
        result = NotificationResult(False, request.notification_id, request.channel, request.recipient, "failed", self.max_attempts, last_error)
        self.store.record(request.notification_id, asdict(result))
        if self.security is not None:
            self.security.audit.record("notification_failed", actor=request.actor, result="error", details={"notification_id": request.notification_id, "channel": request.channel, "attempts": self.max_attempts, "error": last_error})
        return result
