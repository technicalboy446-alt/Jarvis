# Target 29 — Notifications & Messaging

Canonical outbound notification boundary for JARVIS.

- `NotificationManager` owns delivery, retries, idempotency, history, and security authorization.
- `NotificationAdapter` keeps provider-specific implementations isolated.
- `CallableAdapter` can wrap existing WhatsApp, email, Google Chat, webhook, or desktop senders without replacing them.
- `MemoryAdapter` is deterministic for testing/local delivery.
- `MessageTemplates` provides English/Arabic combined output.
- `AlertNotifier` bridges structured automation/health alerts to explicit recipients.
- `automation/notification_jobs.py` registers notification workflows in the existing Target 20 runtime.
