from __future__ import annotations
from typing import Any, Callable, Mapping

class NotificationAdapter:
    channel = "unknown"
    def send(self, recipient: str, *, subject: str, text: str, metadata: Mapping[str, Any]) -> str:
        raise NotImplementedError

class CallableAdapter(NotificationAdapter):
    def __init__(self, channel: str, sender: Callable[..., Any]) -> None:
        self.channel = channel
        self.sender = sender
    def send(self, recipient: str, *, subject: str, text: str, metadata: Mapping[str, Any]) -> str:
        result = self.sender(recipient=recipient, subject=subject, text=text, metadata=dict(metadata))
        return "" if result is None else str(result)

class MemoryAdapter(NotificationAdapter):
    channel = "memory"
    def __init__(self) -> None:
        self.messages: list[dict[str, Any]] = []
    def send(self, recipient: str, *, subject: str, text: str, metadata: Mapping[str, Any]) -> str:
        self.messages.append({"recipient": recipient, "subject": subject, "text": text, "metadata": dict(metadata)})
        return f"memory-{len(self.messages)}"
