from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping
from uuid import uuid4

@dataclass(frozen=True, slots=True)
class NotificationRequest:
    channel: str
    recipient: str
    subject: str = ""
    text: str = ""
    metadata: Mapping[str, Any] = field(default_factory=dict)
    notification_id: str = field(default_factory=lambda: uuid4().hex)
    actor: str = "jarvis"

@dataclass(frozen=True, slots=True)
class NotificationResult:
    ok: bool
    notification_id: str
    channel: str
    recipient: str
    status: str
    attempts: int = 0
    message: str = ""
    provider_id: str | None = None
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
