from __future__ import annotations
from typing import Callable
from automation.alerts.alerts import Alert
from .manager import NotificationManager
from .models import NotificationRequest
from .templates import MessageTemplates

class AlertNotifier:
    """Turn structured JARVIS alerts into outbound notifications.

    Delivery is explicit: the caller chooses a channel and recipient. This
    keeps alerts safe by default and avoids silently broadcasting sensitive data.
    """
    def __init__(self, manager: NotificationManager):
        self.manager = manager

    def notify(self, alert: Alert, *, channel: str, recipient: str, actor: str = "jarvis"):
        msg = MessageTemplates.alert(
            severity=alert.severity,
            title=alert.title,
            message=alert.message,
            arabic_message=str(alert.metadata.get("arabic_message", "")),
        )
        return self.manager.send(NotificationRequest(
            channel=channel,
            recipient=recipient,
            subject=alert.title,
            text=msg.combined,
            metadata={"severity": alert.severity, "alert_created_at": alert.created_at},
            actor=actor,
        ))
