from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping

@dataclass(frozen=True, slots=True)
class BilingualMessage:
    english: str
    arabic: str
    combined: str

class MessageTemplates:
    @staticmethod
    def management_report(*, period: str, summary: str, english: str = "", arabic: str = "") -> BilingualMessage:
        en = english or f"JARVIS {period.title()} Report\n{summary}"
        ar = arabic or f"تقرير JARVIS {period}\n{summary}"
        return BilingualMessage(en, ar, f"{en}\n\nالعربية:\n{ar}")

    @staticmethod
    def alert(*, severity: str, title: str, message: str, arabic_message: str = "") -> BilingualMessage:
        ar = arabic_message or message
        en = f"[{severity.upper()}] {title}\n{message}"
        return BilingualMessage(en, ar, f"{en}\n\nالعربية:\n[{severity.upper()}] {title}\n{ar}")
