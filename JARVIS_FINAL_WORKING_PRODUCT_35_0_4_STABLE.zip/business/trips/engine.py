from decimal import Decimal
from collections import defaultdict

class TripEngine:
    def net_quantity(self, trip):
        return trip.net_weight

    def total_quantity(self, trips, *, company_id=None, vehicle_id=None, material_id=None):
        total = Decimal("0")
        for t in trips:
            if vehicle_id is not None and t.vehicle_id != vehicle_id: continue
            if material_id is not None and t.material_id != material_id: continue
            total += Decimal(str(t.net_weight or 0))
        return total

    def count(self, trips, **filters):
        return sum(1 for t in trips if all(getattr(t, k, None) == v for k, v in filters.items()))

    def totals_by_vehicle(self, trips):
        out = defaultdict(lambda: Decimal("0"))
        for t in trips: out[t.vehicle_id] += Decimal(str(t.net_weight or 0))
        return dict(out)
