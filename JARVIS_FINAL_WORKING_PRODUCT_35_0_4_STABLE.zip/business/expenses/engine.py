from decimal import Decimal
from collections import defaultdict

class ExpenseEngine:
    def total(self, expenses, *, company_id=None, category=None):
        return sum((e.amount for e in expenses if (company_id is None or e.company_id == company_id) and (category is None or e.category == category)), Decimal("0"))

    def by_category(self, expenses, *, company_id=None):
        totals = defaultdict(lambda: Decimal("0"))
        for e in expenses:
            if company_id is None or e.company_id == company_id:
                totals[e.category] += e.amount
        return dict(totals)
