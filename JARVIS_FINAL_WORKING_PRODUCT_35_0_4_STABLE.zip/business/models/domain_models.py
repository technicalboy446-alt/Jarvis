from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Optional

@dataclass(frozen=True)
class Company:
    id: str
    name: str

@dataclass(frozen=True)
class Vehicle:
    id: str
    plate_number: str = ""
    company_id: Optional[str] = None

@dataclass(frozen=True)
class Material:
    id: str
    name: str
    unit: str = ""

@dataclass(frozen=True)
class Trip:
    id: str
    trip_date: date
    vehicle_id: str
    material_id: Optional[str] = None
    customer_id: Optional[str] = None
    driver: str = ""
    gross_weight: Optional[Decimal] = None
    empty_weight: Optional[Decimal] = None
    quantity: Optional[Decimal] = None
    unit_price: Optional[Decimal] = None

    @property
    def net_weight(self):
        if self.quantity is not None:
            return self.quantity
        if self.gross_weight is not None and self.empty_weight is not None:
            return self.gross_weight - self.empty_weight
        return None

    @property
    def amount(self):
        if self.net_weight is None or self.unit_price is None:
            return None
        return self.net_weight * self.unit_price

@dataclass(frozen=True)
class Expense:
    id: str
    expense_date: date
    category: str
    amount: Decimal
    company_id: Optional[str] = None
    description: str = ""

@dataclass(frozen=True)
class Payment:
    id: str
    payment_date: date
    amount: Decimal
    company_id: Optional[str] = None
    invoice_id: Optional[str] = None
    reference: str = ""
