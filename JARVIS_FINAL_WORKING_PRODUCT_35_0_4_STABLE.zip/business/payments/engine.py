from decimal import Decimal

class PaymentEngine:
    def total_paid(self, payments, *, company_id=None):
        return sum((p.amount for p in payments if company_id is None or p.company_id == company_id), Decimal("0"))

    def outstanding(self, invoiced_amount, payments, *, company_id=None):
        return Decimal(str(invoiced_amount)) - self.total_paid(payments, company_id=company_id)
