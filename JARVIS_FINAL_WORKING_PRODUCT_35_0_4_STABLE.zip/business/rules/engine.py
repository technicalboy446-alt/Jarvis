class BusinessRuleEngine:
    def evaluate(self, record):
        issues=[]
        if hasattr(record, "net_weight") and record.net_weight is not None and record.net_weight < 0:
            issues.append("negative_net_weight")
        if hasattr(record, "amount") and record.amount is not None and record.amount < 0:
            issues.append("negative_amount")
        return issues
