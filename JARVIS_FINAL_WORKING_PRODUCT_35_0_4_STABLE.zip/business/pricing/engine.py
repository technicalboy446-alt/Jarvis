from dataclasses import dataclass
from decimal import Decimal
from typing import Optional

@dataclass(frozen=True)
class PriceRule:
    key: str
    unit_price: Decimal
    unit: str = ""
    company_id: Optional[str] = None
    material_id: Optional[str] = None

class PricingEngine:
    def __init__(self, rules=()):
        self._rules = list(rules)

    def add_rule(self, rule: PriceRule):
        self._rules.append(rule)

    def find(self, *, company_id=None, material_id=None, key=None):
        candidates = [r for r in self._rules if (key is None or r.key == key)]
        if company_id is not None:
            candidates = [r for r in candidates if r.company_id in (None, company_id)]
        if material_id is not None:
            candidates = [r for r in candidates if r.material_id in (None, material_id)]
        return max(candidates, key=lambda r: (r.company_id is not None, r.material_id is not None), default=None)

    def calculate(self, quantity, *, company_id=None, material_id=None, key=None):
        rule = self.find(company_id=company_id, material_id=material_id, key=key)
        if rule is None:
            raise LookupError("No applicable pricing rule")
        return Decimal(str(quantity)) * rule.unit_price
