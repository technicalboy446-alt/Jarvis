# JARVIS Business Engine

Canonical domain models and calculation services for companies, vehicles, materials, trips, pricing, expenses and payments.

Business logic belongs here. Source-specific parsing belongs in `data/`; Google API handling belongs in `connectors/`; report rendering belongs in `reports/`.
