# TARGET 29 — Notifications & Messaging Architecture

## Scope
A canonical outbound notification layer for JARVIS. Existing provider adapters are preserved and can be wrapped through `CallableAdapter`.

## Flow
Request / Alert / Automation Job
→ NotificationManager
→ Security/RBAC authorization
→ Channel Adapter
→ Retry with bounded backoff
→ Idempotent history
→ Delivery result + audit event

## Channels
Providers are explicit registrations. The default test channel is `memory`. Existing WhatsApp, email, Google Chat, webhook, and desktop senders can be adapted without duplicating their provider implementations.

## Safety
- Unsupported channels fail closed.
- Sending requires WRITE authorization when a SecurityManager is attached.
- Notification IDs prevent duplicate delivery.
- Failed delivery is persisted as history and audited.
- Bilingual templates support English + Arabic combined messages.
- Alerts are never broadcast implicitly; `AlertNotifier` requires an explicit channel and recipient.
