"""Target 2 local health check; never contacts external services by default."""
from __future__ import annotations

import importlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def check_import(name: str) -> tuple[bool, str]:
    try:
        importlib.import_module(name)
        return True, "ok"
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def main() -> int:
    checks = [
        "core.assistant.bootstrap",
        "core.configuration.config_manager",
        "core.llm.client_adapter",
        "core.routing.router",
        "interface.desktop.ui",
        "interface.voice.audio_devices",
        "interface.dashboard.server",
    ]
    failed = 0
    for name in checks:
        ok, detail = check_import(name)
        if ok:
            print(f"PASS  {name}: {detail}")
        elif "No module named 'PyQt6'" in detail and name == "interface.desktop.ui":
            print(f"BLOCKED-DEPENDENCY  {name}: PyQt6 is not installed in this validation environment")
        else:
            print(f"FAIL  {name}: {detail}")
            failed += 1
    try:
        from core.assistant.bootstrap import bootstrap
        cfg = bootstrap()
        print(f"PASS  bootstrap: base={ROOT} configured={cfg.configured}")
    except Exception as exc:
        print(f"FAIL  bootstrap: {type(exc).__name__}: {exc}")
        failed += 1
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
