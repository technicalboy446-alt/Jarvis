"""JARVIS tool permission policy."""
from __future__ import annotations

from dataclasses import dataclass
from .base_tool import Permission, Tool


_RANK = {
    Permission.READ: 0,
    Permission.WRITE: 1,
    Permission.DESTRUCTIVE: 2,
    Permission.ADMIN: 3,
}


@dataclass(frozen=True, slots=True)
class ToolPolicy:
    max_permission: Permission = Permission.WRITE
    allow_destructive: bool = False
    allow_admin: bool = False

    def allows(self, tool: Tool) -> tuple[bool, str]:
        permission = tool.permission
        if permission is Permission.DESTRUCTIVE and not self.allow_destructive:
            return False, "Destructive tools are disabled by policy."
        if permission is Permission.ADMIN and not self.allow_admin:
            return False, "Administrative tools are disabled by policy."
        if _RANK[permission] > _RANK[self.max_permission]:
            return False, f"Permission '{permission.value}' exceeds policy limit '{self.max_permission.value}'."
        return True, "allowed"
