"""Canonical JARVIS tool registry.

The registry owns discovery, not execution. Tool implementations can therefore
remain in MARK LII, Hermes, connectors, or future business modules while JARVIS
uses one stable interface.
"""
from __future__ import annotations

from typing import Iterable
from .base_tool import Tool


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool, *, replace: bool = False) -> None:
        name = str(tool.name).strip().lower()
        if not name:
            raise ValueError("Tool name cannot be empty")
        if name in self._tools and not replace:
            raise ValueError(f"Tool already registered: {tool.name}")
        self._tools[name] = tool

    def register_many(self, tools: Iterable[Tool], *, replace: bool = False) -> None:
        for tool in tools:
            self.register(tool, replace=replace)

    def get(self, name: str) -> Tool:
        key = str(name).strip().lower()
        if key not in self._tools:
            raise KeyError(f"Unknown JARVIS tool: {name}")
        return self._tools[key]

    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._tools))

    def describe(self) -> list[dict[str, object]]:
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "permission": tool.permission.value,
                "requires_confirmation": bool(tool.requires_confirmation),
            }
            for tool in (self._tools[name] for name in self.names())
        ]
