"""Canonical JARVIS tool contract.

Tools are deliberately provider-agnostic. Existing MARK LII/Hermes tools can be
adapted behind this interface without forcing a repository-wide rewrite.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Mapping, Protocol


class Permission(str, Enum):
    READ = "read"
    WRITE = "write"
    DESTRUCTIVE = "destructive"
    ADMIN = "admin"


@dataclass(frozen=True, slots=True)
class ToolContext:
    user_id: str = "local"
    source: str = "assistant"
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ToolResult:
    ok: bool
    tool: str
    output: Any = None
    error: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


class Tool(Protocol):
    name: str
    description: str
    permission: Permission
    requires_confirmation: bool

    def execute(self, arguments: Mapping[str, Any], context: ToolContext) -> ToolResult: ...


class BaseTool:
    name = "base"
    description = "Base JARVIS tool contract."
    permission = Permission.READ
    requires_confirmation = False

    def validate(self, arguments: Mapping[str, Any]) -> None:
        if not isinstance(arguments, Mapping):
            raise TypeError("Tool arguments must be a mapping")

    def execute(self, arguments: Mapping[str, Any], context: ToolContext) -> ToolResult:
        raise NotImplementedError


class FunctionTool(BaseTool):
    """Wrap a normal Python callable as a JARVIS tool."""

    def __init__(
        self,
        name: str,
        description: str,
        handler: Callable[[Mapping[str, Any], ToolContext], Any],
        permission: Permission = Permission.READ,
        requires_confirmation: bool = False,
    ) -> None:
        self.name = name
        self.description = description
        self.handler = handler
        self.permission = permission
        self.requires_confirmation = requires_confirmation

    def execute(self, arguments: Mapping[str, Any], context: ToolContext) -> ToolResult:
        self.validate(arguments)
        try:
            value = self.handler(arguments, context)
            return ToolResult(ok=True, tool=self.name, output=value)
        except Exception as exc:
            return ToolResult(ok=False, tool=self.name, error=str(exc))
