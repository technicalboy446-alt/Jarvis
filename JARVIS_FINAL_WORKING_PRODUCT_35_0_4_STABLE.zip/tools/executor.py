"""Safe canonical JARVIS tool executor."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
from dataclasses import dataclass
from typing import Mapping, Any

from .base_tool import ToolContext, ToolResult, Permission
from .registry import ToolRegistry
from .policy import ToolPolicy
from core import confirm


@dataclass(frozen=True, slots=True)
class ExecutionPolicy:
    tool_policy: ToolPolicy = ToolPolicy()
    timeout_seconds: float = 30.0
    require_confirmation_for_destructive: bool = True


class ToolExecutor:
    def __init__(self, registry: ToolRegistry, policy: ExecutionPolicy | None = None) -> None:
        self.registry = registry
        self.policy = policy or ExecutionPolicy()

    def execute(
        self,
        name: str,
        arguments: Mapping[str, Any] | None = None,
        *,
        context: ToolContext | None = None,
    ) -> ToolResult:
        tool = self.registry.get(name)
        arguments = arguments or {}
        context = context or ToolContext()

        allowed, reason = self.policy.tool_policy.allows(tool)
        if not allowed:
            return ToolResult(ok=False, tool=tool.name, error=reason)

        needs_confirmation = (
            tool.requires_confirmation
            or (
                self.policy.require_confirmation_for_destructive
                and tool.permission in {Permission.DESTRUCTIVE, Permission.ADMIN}
            )
        )
        if needs_confirmation:
            return ToolResult(
                ok=False,
                tool=tool.name,
                error=confirm.request(
                    key=tool.name,
                    title=f"Run tool: {tool.name}",
                    detail=tool.description,
                    run=lambda: self._run(tool, arguments, context).output or "Done.",
                ),
                metadata={"confirmation_pending": True},
            )

        return self._run(tool, arguments, context)

    def _run(self, tool, arguments, context) -> ToolResult:
        pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix=f"jarvis-tool-{tool.name}")
        future = pool.submit(tool.execute, arguments, context)
        try:
            return future.result(timeout=self.policy.timeout_seconds)
        except FutureTimeout:
            future.cancel()
            pool.shutdown(wait=False, cancel_futures=True)
            return ToolResult(ok=False, tool=tool.name, error=f"Tool timed out after {self.policy.timeout_seconds:.1f}s")
        except Exception as exc:
            pool.shutdown(wait=False, cancel_futures=True)
            return ToolResult(ok=False, tool=tool.name, error=str(exc))
        else:
            pool.shutdown(wait=False, cancel_futures=True)
