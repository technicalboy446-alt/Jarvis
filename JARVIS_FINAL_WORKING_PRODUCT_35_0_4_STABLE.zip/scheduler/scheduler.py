from __future__ import annotations
from datetime import datetime
from automation.engine import AutomationEngine
from automation.runtime import WorkflowRuntime
from automation.triggers.schedule import matches_simple_schedule

class Scheduler:
    def __init__(self, engine: AutomationEngine, runtime: WorkflowRuntime | None = None):
        self.engine = engine
        self.runtime = runtime or WorkflowRuntime(engine, engine.store)

    def due_jobs(self, when: datetime | None = None):
        when = when or datetime.now()
        return [j for j in self.engine.store.list_jobs() if j.enabled and matches_simple_schedule(j.schedule, when)]

    def tick(self, when: datetime | None = None):
        when = when or datetime.now()
        scheduled_for = when.isoformat()
        return [self.runtime.run(j.job_id, scheduled_for=scheduled_for) for j in self.due_jobs(when)]
