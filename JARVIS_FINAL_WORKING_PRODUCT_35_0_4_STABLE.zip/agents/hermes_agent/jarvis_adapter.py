"""Lazy adapter exposing the Hermes AIAgent through the JARVIS agent contract."""
from __future__ import annotations
from typing import Any
from agents.base_agent import AgentRequest, AgentResponse, BaseAgent

class HermesAgentAdapter(BaseAgent):
    name = "hermes"
    description = "Hermes runtime-backed general-purpose JARVIS agent."

    def __init__(self, *, base_url: str | None = None, api_key: str | None = None,
                 provider: str | None = None, model: str = "", **kwargs: Any) -> None:
        self._config = dict(base_url=base_url, api_key=api_key, provider=provider,
                            model=model, **kwargs)
        self._agent: Any | None = None

    def _ensure_agent(self) -> Any:
        if self._agent is None:
            from agents.hermes_engine.run_agent import AIAgent
            self._agent = AIAgent(**{k: v for k, v in self._config.items() if v is not None})
        return self._agent

    def run(self, request: AgentRequest) -> AgentResponse:
        agent = self._ensure_agent()
        result = agent.run_conversation(
            request.text,
            system_message=request.system,
            task_id=str(request.metadata.get("task_id")) if request.metadata.get("task_id") else None,
        )
        if isinstance(result, dict):
            text = result.get("content") or result.get("text") or result.get("response") or ""
        else:
            text = str(result)
        return AgentResponse(text=str(text), agent=self.name, raw=result)
