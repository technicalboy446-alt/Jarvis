"""Canonical JARVIS agent registry."""
from __future__ import annotations
from typing import Any
from .base_agent import Agent

class AgentRegistry:
    def __init__(self) -> None:
        self._factories: dict[str, Any] = {}
        self._instances: dict[str, Agent] = {}

    def register(self, name: str, factory: Any, *, replace: bool = False) -> None:
        key = name.strip().lower()
        if not key:
            raise ValueError("Agent name cannot be empty")
        if key in self._factories and not replace:
            raise ValueError(f"Agent already registered: {name}")
        self._factories[key] = factory
        self._instances.pop(key, None)

    def get(self, name: str) -> Agent:
        key = name.strip().lower()
        if key not in self._factories:
            raise KeyError(f"Unknown JARVIS agent: {name}")
        if key not in self._instances:
            self._instances[key] = self._factories[key]()
        return self._instances[key]

    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._factories))
