"""Canonical JARVIS agent contract.

Agents expose a stable interface; implementation details (Hermes, future agents,
or specialized business agents) remain behind this boundary.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Protocol

@dataclass(slots=True)
class AgentRequest:
    text: str
    system: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass(slots=True)
class AgentResponse:
    text: str
    agent: str
    raw: Any = None
    metadata: dict[str, Any] = field(default_factory=dict)

class Agent(Protocol):
    name: str
    description: str
    def run(self, request: AgentRequest) -> AgentResponse: ...

class BaseAgent:
    """Base implementation for JARVIS agents."""
    name = "base"
    description = "Base JARVIS agent contract."

    def run(self, request: AgentRequest) -> AgentResponse:
        raise NotImplementedError
