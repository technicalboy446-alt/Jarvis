"""JARVIS agent lifecycle manager."""
from __future__ import annotations
from .base_agent import AgentRequest, AgentResponse
from .registry import AgentRegistry

class AgentManager:
    def __init__(self, registry: AgentRegistry) -> None:
        self.registry = registry

    def run(self, agent_name: str, request: AgentRequest) -> AgentResponse:
        return self.registry.get(agent_name).run(request)


def build_default_registry() -> AgentRegistry:
    registry = AgentRegistry()
    from .hermes_agent.jarvis_adapter import HermesAgentAdapter
    registry.register("hermes", HermesAgentAdapter)
    return registry
