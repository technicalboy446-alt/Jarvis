from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

@dataclass
class Alert:
    severity: str
    title: str
    message: str
    created_at: str
    metadata: dict[str, Any]

class AlertManager:
    def __init__(self): self._alerts: list[Alert] = []
    def emit(self, severity: str, title: str, message: str, **metadata: Any) -> Alert:
        alert = Alert(severity, title, message, datetime.now(timezone.utc).isoformat(), metadata)
        self._alerts.append(alert); return alert
    def list(self) -> list[Alert]: return list(self._alerts)
