"""Target 29 automation-ready notification job helpers."""
from __future__ import annotations
from typing import Callable
from automation.engine import AutomationEngine
from automation.models import JobSpec
from notifications.manager import NotificationManager
from notifications.models import NotificationRequest


def register_notification_job(
    engine: AutomationEngine,
    manager: NotificationManager,
    *,
    name: str = "JARVIS Notification",
    channel: str = "memory",
    recipient: str = "local",
    text_supplier: Callable[[], str] = lambda: "JARVIS notification",
) -> None:
    def handler(job: JobSpec) -> str:
        req = NotificationRequest(
            channel=job.metadata.get("channel", channel),
            recipient=job.metadata.get("recipient", recipient),
            subject=job.metadata.get("subject", name),
            text=text_supplier(),
            metadata={"job_id": job.job_id},
            notification_id=job.metadata.get("notification_id", job.job_id),
        )
        result = manager.send(req)
        if not result.ok:
            raise RuntimeError(result.message or result.status)
        return f"Notification {result.status}: {result.channel}/{result.recipient}"

    engine.register_handler("notification", handler)
    engine.add_job(JobSpec(
        name=name,
        kind="notification",
        schedule="manual",
        handler="notification",
        read_only=True,
        metadata={"channel": channel, "recipient": recipient},
    ))
