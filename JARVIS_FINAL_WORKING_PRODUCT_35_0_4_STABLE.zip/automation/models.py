from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Literal
import uuid

JobStatus = Literal['enabled', 'disabled', 'running', 'failed']

@dataclass
class JobSpec:
    name: str
    kind: str
    schedule: str
    handler: str
    enabled: bool = True
    read_only: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)
    job_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass
class JobRun:
    job_id: str
    started_at: str
    finished_at: str | None = None
    status: JobStatus = 'running'
    message: str = ''
    run_id: str = field(default_factory=lambda: uuid.uuid4().hex)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
