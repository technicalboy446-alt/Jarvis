"""Target 20 durable automation runtime.

Adds retries, idempotency, concurrency guards, structured execution state,
and integration hooks without replacing AutomationEngine/Scheduler.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import threading
import time
from typing import Any, Callable

from .engine import AutomationEngine
from .models import JobRun, JobSpec
from .store import AutomationStore
from automation.alerts.alerts import AlertManager
from core.observability import ObservabilityManager
from security.manager import SecurityManager


@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 3
    backoff_seconds: float = 0.25
    multiplier: float = 2.0
    max_backoff_seconds: float = 10.0

    def delay_for(self, attempt: int) -> float:
        return min(self.max_backoff_seconds, self.backoff_seconds * (self.multiplier ** max(0, attempt - 1)))


@dataclass(frozen=True)
class ExecutionRecord:
    job_id: str
    run_id: str
    attempt: int
    status: str
    started_at: str
    finished_at: str | None
    idempotency_key: str
    message: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class WorkflowRuntime:
    """Safe durable execution facade for scheduled automation jobs."""

    def __init__(
        self,
        engine: AutomationEngine,
        store: AutomationStore,
        *,
        security: SecurityManager | None = None,
        observability: ObservabilityManager | None = None,
        alerts: AlertManager | None = None,
        max_concurrent: int = 2,
    ) -> None:
        self.engine = engine
        self.store = store
        self.security = security
        self.observability = observability or ObservabilityManager.create()
        self.alerts = alerts or AlertManager()
        self.max_concurrent = max(1, int(max_concurrent))
        self._semaphore = threading.BoundedSemaphore(self.max_concurrent)
        self._running: set[str] = set()
        self._lock = threading.RLock()
        self._index_path = self.store.base / "execution_index.json"
        if not self._index_path.exists():
            self._index_path.write_text("{}", encoding="utf-8")

    def _load_index(self) -> dict[str, dict[str, Any]]:
        try:
            return json.loads(self._index_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_index(self, data: dict[str, dict[str, Any]]) -> None:
        tmp = self._index_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        tmp.replace(self._index_path)

    @staticmethod
    def idempotency_key(job: JobSpec, *, scheduled_for: str | None = None) -> str:
        raw = f"{job.job_id}|{scheduled_for or 'manual'}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _policy(self, job: JobSpec) -> RetryPolicy:
        raw = dict(job.metadata.get("retry", {}) or {})
        return RetryPolicy(
            max_attempts=max(1, int(raw.get("max_attempts", 3))),
            backoff_seconds=max(0.0, float(raw.get("backoff_seconds", 0.25))),
            multiplier=max(1.0, float(raw.get("multiplier", 2.0))),
            max_backoff_seconds=max(0.0, float(raw.get("max_backoff_seconds", 10.0))),
        )

    def run(self, job_id: str, *, scheduled_for: str | None = None) -> JobRun:
        job = next((j for j in self.store.list_jobs() if j.job_id == job_id), None)
        if job is None:
            raise KeyError(job_id)
        if not job.enabled:
            raise RuntimeError("Job is disabled")

        key = self.idempotency_key(job, scheduled_for=scheduled_for)
        with self._lock:
            index = self._load_index()
            prior = index.get(key)
            if prior and prior.get("status") == "succeeded":
                return JobRun(
                    job_id=job.job_id,
                    started_at=prior["started_at"],
                    finished_at=prior.get("finished_at"),
                    status="enabled",
                    message="Skipped duplicate execution (idempotency key already succeeded).",
                    run_id=prior["run_id"],
                )
            if job.job_id in self._running:
                raise RuntimeError("Job is already running")
            self._running.add(job.job_id)

        self._semaphore.acquire()
        started_at = datetime.now(timezone.utc).isoformat()
        run = JobRun(job_id=job.job_id, started_at=started_at)
        policy = self._policy(job)
        started_monotonic = self.observability.metrics.start()
        self.observability.emit("automation_started", request_id=key, source="scheduler", details={"job_id": job.job_id, "kind": job.kind})
        try:
            if self.security:
                # Reuse Target 16 policy for write-enabled automation.
                if not job.read_only and job.metadata.get("allow_write") is not True:
                    raise PermissionError("Write-enabled automation requires metadata.allow_write=true")

            handler = self.engine.handlers.get(job.handler)
            if handler is None:
                raise KeyError(f"No handler registered: {job.handler}")

            last_error: Exception | None = None
            for attempt in range(1, policy.max_attempts + 1):
                try:
                    result = handler(job)
                    run.status = "enabled"
                    run.message = str(result or "completed")
                    finished_at = datetime.now(timezone.utc).isoformat()
                    run.finished_at = finished_at
                    index = self._load_index()
                    index[key] = ExecutionRecord(job.job_id, run.run_id, attempt, "succeeded", started_at, finished_at, key, run.message).to_dict()
                    self._save_index(index)
                    self.observability.metrics.finish(started_monotonic, ok=True)
                    self.observability.emit("automation_completed", request_id=key, source="scheduler", status="ok", details={"job_id": job.job_id, "attempt": attempt})
                    return run
                except Exception as exc:
                    last_error = exc
                    if attempt < policy.max_attempts:
                        delay = policy.delay_for(attempt)
                        self.observability.emit("automation_retry", request_id=key, source="scheduler", status="warning", details={"job_id": job.job_id, "attempt": attempt, "delay": delay, "error": f"{type(exc).__name__}: {exc}"})
                        if delay:
                            time.sleep(delay)
            assert last_error is not None
            raise last_error
        except Exception as exc:
            run.status = "failed"
            run.message = f"{type(exc).__name__}: {exc}"
            run.finished_at = datetime.now(timezone.utc).isoformat()
            index = self._load_index()
            index[key] = ExecutionRecord(job.job_id, run.run_id, policy.max_attempts, "failed", started_at, run.finished_at, key, run.message).to_dict()
            self._save_index(index)
            self.alerts.emit("error", "Automation job failed", run.message, job_id=job.job_id, run_id=run.run_id)
            self.observability.metrics.finish(started_monotonic, ok=False)
            self.observability.emit("automation_failed", request_id=key, source="scheduler", status="error", details={"job_id": job.job_id, "error": run.message})
            return run
        finally:
            self.store.append_run(run)
            with self._lock:
                self._running.discard(job.job_id)
            self._semaphore.release()

    def status(self) -> dict[str, Any]:
        with self._lock:
            return {
                "running_jobs": sorted(self._running),
                "running_count": len(self._running),
                "max_concurrent": self.max_concurrent,
                "indexed_executions": len(self._load_index()),
                "alerts": len(self.alerts.list()),
            }
