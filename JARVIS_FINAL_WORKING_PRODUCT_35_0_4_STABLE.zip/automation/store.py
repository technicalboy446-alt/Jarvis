from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from .models import JobSpec, JobRun

class AutomationStore:
    def __init__(self, base_dir: str | Path):
        self.base = Path(base_dir)
        self.base.mkdir(parents=True, exist_ok=True)
        self.jobs_path = self.base / 'jobs.json'
        self.runs_path = self.base / 'runs.jsonl'
        if not self.jobs_path.exists(): self.jobs_path.write_text('[]', encoding='utf-8')
        self._last_write = None

    def list_jobs(self) -> list[JobSpec]:
        data = json.loads(self.jobs_path.read_text(encoding='utf-8'))
        return [JobSpec(**x) for x in data]

    def save_job(self, job: JobSpec) -> None:
        jobs = self.list_jobs()
        replaced = False
        for i, current in enumerate(jobs):
            if current.job_id == job.job_id:
                jobs[i] = job; replaced = True; break
        if not replaced: jobs.append(job)
        self.jobs_path.write_text(json.dumps([j.to_dict() for j in jobs], indent=2), encoding='utf-8')

    def append_run(self, run: JobRun) -> None:
        with self.runs_path.open('a', encoding='utf-8') as f:
            f.write(json.dumps(run.to_dict(), ensure_ascii=False) + '\n')
