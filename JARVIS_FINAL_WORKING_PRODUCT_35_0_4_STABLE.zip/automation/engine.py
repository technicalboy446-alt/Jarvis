from __future__ import annotations
from datetime import datetime, timezone
from typing import Callable, Any
from .models import JobSpec, JobRun
from .store import AutomationStore

class AutomationEngine:
    def __init__(self, store: AutomationStore):
        self.store = store
        self.handlers: dict[str, Callable[[JobSpec], Any]] = {}

    def register_handler(self, name: str, handler: Callable[[JobSpec], Any]) -> None:
        self.handlers[name] = handler

    def add_job(self, job: JobSpec) -> JobSpec:
        if job.read_only is False and job.metadata.get('allow_write') is not True:
            raise ValueError('Write-enabled automation requires metadata.allow_write=true')
        self.store.save_job(job)
        return job

    def enable(self, job_id: str, enabled: bool) -> JobSpec:
        jobs = self.store.list_jobs()
        for job in jobs:
            if job.job_id == job_id:
                job.enabled = enabled
                self.store.save_job(job)
                return job
        raise KeyError(job_id)

    def run(self, job_id: str) -> JobRun:
        job = next((j for j in self.store.list_jobs() if j.job_id == job_id), None)
        if job is None: raise KeyError(job_id)
        if not job.enabled: raise RuntimeError('Job is disabled')
        handler = self.handlers.get(job.handler)
        if handler is None: raise KeyError(f'No handler registered: {job.handler}')
        run = JobRun(job_id=job.job_id, started_at=datetime.now(timezone.utc).isoformat())
        try:
            result = handler(job)
            run.status = 'enabled'
            run.message = str(result or 'completed')
        except Exception as exc:
            run.status = 'failed'
            run.message = f'{type(exc).__name__}: {exc}'
        finally:
            run.finished_at = datetime.now(timezone.utc).isoformat()
            self.store.append_run(run)
        return run
