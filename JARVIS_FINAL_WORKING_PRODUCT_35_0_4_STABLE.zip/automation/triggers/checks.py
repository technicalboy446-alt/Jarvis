from __future__ import annotations
from typing import Iterable, Callable, Any
from ..alerts.alerts import AlertManager

class CheckRunner:
    def __init__(self, alerts: AlertManager): self.alerts = alerts
    def run_checks(self, checks: Iterable[Callable[[], Any]]) -> list[Any]:
        results = []
        for check in checks:
            try: results.append(check())
            except Exception as exc:
                results.append(self.alerts.emit('error', 'Automation check failed', str(exc)))
        return results
