from __future__ import annotations
from datetime import datetime

def matches_simple_schedule(schedule: str, when: datetime) -> bool:
    s = schedule.strip().lower()
    if s in {'every_run', 'manual'}: return True
    if s == 'daily': return True
    if s == 'hourly': return when.minute == 0
    if s.startswith('weekday:'):
        days = {x.strip() for x in s.split(':', 1)[1].split(',')}
        return when.strftime('%a').lower()[:3] in days
    return False
