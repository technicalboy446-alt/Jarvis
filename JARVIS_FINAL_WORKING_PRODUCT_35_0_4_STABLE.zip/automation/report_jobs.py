"""Target 27 automation-ready report job registration helpers."""
from __future__ import annotations

from datetime import date
from typing import Callable, Sequence

from automation.engine import AutomationEngine
from automation.models import JobSpec
from reports.pipeline import ReportPipeline


def register_management_report_jobs(
    engine: AutomationEngine,
    pipeline: ReportPipeline,
    *,
    trip_supplier: Callable[[], Sequence] = lambda: (),
    expense_supplier: Callable[[], Sequence] = lambda: (),
    payment_supplier: Callable[[], Sequence] = lambda: (),
) -> None:
    """Register read-only daily/weekly/monthly management-report jobs."""
    def handler(job: JobSpec) -> str:
        kind = job.metadata.get("period", "daily")
        anchor = date.fromisoformat(job.metadata.get("anchor_date", date.today().isoformat()))
        bundle = pipeline.write_management(
            kind=kind,
            anchor=anchor,
            trips=trip_supplier(),
            expenses=expense_supplier(),
            payments=payment_supplier(),
            invoiced_amount=job.metadata.get("invoiced_amount", 0),
        )
        return f"Generated {kind} English + Arabic management reports: {bundle.bilingual_json}"

    engine.register_handler("management_report", handler)
    for period, schedule in (("daily", "daily"), ("weekly", "weekly"), ("monthly", "monthly")):
        engine.add_job(
            JobSpec(
                name=f"{period.title()} Management Report",
                kind="report",
                schedule=schedule,
                handler="management_report",
                read_only=True,
                metadata={"period": period},
            )
        )
