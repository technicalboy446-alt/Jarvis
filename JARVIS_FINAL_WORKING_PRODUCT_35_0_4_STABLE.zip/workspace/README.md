# JARVIS Workspace

Canonical file-management workspace for JARVIS.

- `incoming/` — newly received files awaiting processing
- `processed/` — files that have been handled
- `reports/` — generated business/report outputs
- `statements/` — financial/statements documents
- `archives/` — retained historical files
- `metadata/file_manifest.jsonl` — append-only filing audit trail

Use `WorkspaceManager` for programmatic filing/search. Direct writes outside the workspace manager should be avoided for automated workflows.
