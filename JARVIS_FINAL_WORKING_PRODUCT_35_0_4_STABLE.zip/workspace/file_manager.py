from __future__ import annotations

import hashlib
import json
import re
import shutil
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Iterable


CATEGORIES = {"incoming", "processed", "reports", "statements", "archives"}
_FILENAME_SAFE = re.compile(r"[^A-Za-z0-9._ -]+")


@dataclass(frozen=True)
class FileRecord:
    name: str
    path: str
    category: str
    size: int
    modified_at: str
    sha256: str


class WorkspaceManager:
    """Controlled filing/search layer for JARVIS workspace files."""

    def __init__(self, root: str | Path | None = None):
        self.root = Path(root or Path(__file__).resolve().parent).resolve()
        self.meta_dir = self.root / "metadata"
        self.manifest_path = self.meta_dir / "file_manifest.jsonl"
        self.meta_dir.mkdir(parents=True, exist_ok=True)
        for category in CATEGORIES:
            (self.root / category).mkdir(parents=True, exist_ok=True)

    def category_path(self, category: str) -> Path:
        category = self._check_category(category)
        return self.root / category

    @staticmethod
    def _check_category(category: str) -> str:
        if category not in CATEGORIES:
            raise ValueError(f"Unsupported workspace category: {category}")
        return category

    @staticmethod
    def _safe_name(name: str) -> str:
        cleaned = _FILENAME_SAFE.sub("", Path(name).name).strip(" .")
        if not cleaned:
            raise ValueError("Filename is empty after sanitization")
        return cleaned

    def _hash(self, path: Path, chunk_size: int = 1024 * 1024) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            while chunk := handle.read(chunk_size):
                digest.update(chunk)
        return digest.hexdigest()

    def _record(self, path: Path, category: str) -> FileRecord:
        stat = path.stat()
        return FileRecord(
            name=path.name,
            path=str(path.relative_to(self.root)),
            category=category,
            size=stat.st_size,
            modified_at=datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
            sha256=self._hash(path),
        )

    def _append_manifest(self, record: FileRecord, action: str) -> None:
        payload = {"timestamp": datetime.now().isoformat(timespec="seconds"), "action": action, **asdict(record)}
        with self.manifest_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=False) + "\n")

    def ingest(self, source: str | Path, *, overwrite: bool = False) -> FileRecord:
        """Copy a file into incoming/ without allowing arbitrary destination traversal."""
        src = Path(source).expanduser().resolve()
        if not src.is_file():
            raise FileNotFoundError(src)
        target = self.category_path("incoming") / self._safe_name(src.name)
        if target.exists() and not overwrite:
            target = self._dedupe_name(target)
        shutil.copy2(src, target)
        record = self._record(target, "incoming")
        self._append_manifest(record, "ingest")
        return record

    def file_in_category(self, category: str, name: str) -> Path:
        target = self.category_path(category) / self._safe_name(name)
        return target

    def move(self, name: str, source_category: str, target_category: str, *, overwrite: bool = False) -> FileRecord:
        src = self.file_in_category(source_category, name)
        if not src.is_file():
            raise FileNotFoundError(src)
        target = self.category_path(target_category) / self._safe_name(src.name)
        if target.exists() and not overwrite:
            target = self._dedupe_name(target)
        shutil.move(str(src), str(target))
        record = self._record(target, target_category)
        self._append_manifest(record, f"move:{source_category}->{target_category}")
        return record

    def archive(self, name: str, source_category: str = "processed") -> FileRecord:
        return self.move(name, source_category, "archives")

    def search(self, query: str, *, categories: Iterable[str] | None = None) -> list[FileRecord]:
        selected = list(categories) if categories is not None else sorted(CATEGORIES)
        for category in selected:
            self._check_category(category)
        q = query.casefold().strip()
        results: list[FileRecord] = []
        for category in selected:
            folder = self.category_path(category)
            for path in folder.rglob("*"):
                if path.is_file() and q in path.name.casefold():
                    results.append(self._record(path, category))
        return sorted(results, key=lambda r: (r.category, r.name.casefold()))

    def classify(self, filename: str) -> str:
        """Best-effort category suggestion; final filing is explicit."""
        name = filename.casefold()
        if any(token in name for token in ("invoice", "statement", "payment", "receipt")):
            return "statements"
        if any(token in name for token in ("report", "summary", "analysis")):
            return "reports"
        return "incoming"

    def _dedupe_name(self, target: Path) -> Path:
        stem, suffix = target.stem, target.suffix
        for idx in range(1, 10000):
            candidate = target.with_name(f"{stem} ({idx}){suffix}")
            if not candidate.exists():
                return candidate
        raise RuntimeError("Unable to find a safe duplicate filename")
