# Target 27 Architecture

Business/data sources -> existing report builders -> ReportPipeline -> English JSON/CSV + English/Arabic JSON/CSV -> organized period folders.

AutomationEngine can register read-only daily, weekly and monthly management-report jobs. Target 20 WorkflowRuntime provides retries/idempotency/concurrency when those jobs are executed.

PDF generation is intentionally not added; the current JARVIS scope keeps PDF generation deferred.
