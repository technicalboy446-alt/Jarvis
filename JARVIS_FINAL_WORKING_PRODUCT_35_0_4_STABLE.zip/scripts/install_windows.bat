@echo off
setlocal
cd /d "%~dp0.."
set "PY=py -3.11"
%PY% -V >nul 2>&1 || set "PY=py -3.12"
%PY% -m venv .venv
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m playwright install chromium
if errorlevel 1 exit /b 1
if not exist config mkdir config
if not exist memory mkdir memory
if not exist workspace mkdir workspace
if not exist logs mkdir logs
echo.
echo JARVIS 35.0.4 installation complete.
echo Create config\api_keys.json before first launch.
