#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
PYTHON_BIN="$(command -v python3.11 || command -v python3.12 || command -v python3)"
"$PYTHON_BIN" -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m playwright install chromium
mkdir -p config memory workspace logs
printf '\nJARVIS 35.0.4 installation complete.\nCreate config/api_keys.json before first launch.\n'
