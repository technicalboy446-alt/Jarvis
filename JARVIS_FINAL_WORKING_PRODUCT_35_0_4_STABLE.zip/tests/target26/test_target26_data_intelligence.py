from data.google_sheets.intelligence import SheetIntelligence, normalize_sheet


def sample():
    return normalize_sheet([
        {"Date": "01/09/2026", "Truck No": "T-1", "Gross Weight": "35,000", "Empty Weight": "21,500", "Rate": "2"},
        {"Date": "2026-09-02", "Truck No": "T-2", "Quantity": "10", "Unit Price": "3"},
        {"Date": "2026-10-01", "Truck No": "T-3", "Quantity": "4", "Unit Price": "5"},
    ], source="Trips")


def test_schema_normalization_and_derivation():
    ds = sample()
    si = SheetIntelligence()
    si.derive_amount(si.derive_net_quantity(ds))
    assert ds.rows[0]["quantity"] == 13500.0
    assert ds.rows[0]["unit_price"] == 2
    assert ds.rows[0]["total"] == 27000.0


def test_daily_summary():
    out = SheetIntelligence().daily_summary(sample(), value_field="quantity")
    assert out[0]["date"] == "2026-09-01" and out[0]["quantity"] == 13500.0


def test_monthly_summary():
    ds = sample(); SheetIntelligence().derive_net_quantity(ds)
    out = SheetIntelligence().monthly_summary(ds, value_field="quantity")
    assert [x["month"] for x in out] == ["2026-09", "2026-10"]
    assert out[0]["quantity"] == 13510.0


def test_schema_comparison():
    a = normalize_sheet([{"Date": "2026-09-01", "Truck": "T1"}], source="A")
    b = normalize_sheet([{"Date": "2026-09-01", "Driver": "Ali"}], source="B")
    comp = SheetIntelligence().compare_schemas([a, b])
    assert "date" in comp["common_columns"]
    assert "driver" in comp["union_columns"]


def test_profile():
    ds = sample(); p = SheetIntelligence().profile(ds)
    assert p.row_count == 3 and p.date_column == "date" and "quantity" in p.mapped_columns


def test_no_date_rows_do_not_break_summaries():
    ds = normalize_sheet([{"Truck": "T1", "Quantity": "5"}], source="NoDate")
    si = SheetIntelligence()
    assert si.daily_summary(ds) == []
