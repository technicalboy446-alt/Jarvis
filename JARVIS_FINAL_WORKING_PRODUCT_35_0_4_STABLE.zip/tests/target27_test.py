from datetime import date
from decimal import Decimal
from pathlib import Path

from automation.engine import AutomationEngine
from automation.report_jobs import register_management_report_jobs
from automation.store import AutomationStore
from reports.bilingual import bilingual_report
from reports.pipeline import ReportPipeline
from business.models.domain_models import Expense, Payment, Trip


def sample():
    d = date(2026, 9, 12)
    trips = [Trip("t1", d, "V1", quantity=Decimal("10"), unit_price=Decimal("5"))]
    expenses = [Expense("e1", d, "fuel", Decimal("12"))]
    payments = [Payment("p1", d, Decimal("20"))]
    return d, trips, expenses, payments


def test_periods():
    d = date(2026, 9, 12)
    assert ReportPipeline.period("daily", d) == (d, d)
    assert ReportPipeline.period("weekly", d)[0].weekday() == 0
    assert ReportPipeline.period("monthly", d) == (date(2026, 9, 1), date(2026, 9, 30))


def test_bilingual_report_has_arabic_columns():
    d, trips, expenses, payments = sample()
    report = ReportPipeline().build_management(kind="daily", anchor=d, trips=trips, expenses=expenses, payments=payments)
    payload = bilingual_report(report)
    assert payload["name"]["ar"]
    assert any(c["ar"] == "المؤشر" for c in payload["columns"] if c["key"] == "metric")


def test_write_creates_en_ar_files(tmp_path):
    d, trips, expenses, payments = sample()
    bundle = ReportPipeline(tmp_path).write_management(kind="daily", anchor=d, trips=trips, expenses=expenses, payments=payments)
    for path in (bundle.english_json, bundle.bilingual_json, bundle.english_csv, bundle.bilingual_csv):
        assert Path(path).exists()
        assert Path(path).read_text(encoding="utf-8-sig")


def test_reports_are_filed_by_period(tmp_path):
    d, trips, expenses, payments = sample()
    bundle = ReportPipeline(tmp_path).write_management(kind="monthly", anchor=d, trips=trips, expenses=expenses, payments=payments)
    assert bundle.bilingual_json.parent == tmp_path / "monthly" / "2026-09"


def test_bilingual_summary_contains_management_metrics():
    d, trips, expenses, payments = sample()
    report = ReportPipeline().build_management(kind="daily", anchor=d, trips=trips, expenses=expenses, payments=payments)
    payload = bilingual_report(report)
    assert "trip_count" in payload["summary"]
    assert "expense_total" in payload["summary"]


def test_job_registration_exposes_three_periods(tmp_path):
    engine = AutomationEngine(AutomationStore(tmp_path / "automation"))
    register_management_report_jobs(engine, ReportPipeline(tmp_path / "reports"))
    jobs = engine.store.list_jobs()
    assert {j.metadata["period"] for j in jobs} == {"daily", "weekly", "monthly"}
