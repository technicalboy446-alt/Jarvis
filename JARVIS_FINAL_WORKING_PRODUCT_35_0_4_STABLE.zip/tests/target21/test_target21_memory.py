from datetime import datetime, timezone, timedelta
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from memory.interface import JarvisMemory
from memory.intelligence import MemoryIntelligence
from memory.types import MemoryScope, MemoryRecord


def test_ranked_search_prefers_important_recent_memory(tmp_path):
    m = JarvisMemory(tmp_path / "m.json")
    m.remember("old", "same project", MemoryScope.LONG_TERM, importance=1,
               updated_at=(datetime.now(timezone.utc) - timedelta(days=30)).isoformat())
    m.remember("new", "same project", MemoryScope.LONG_TERM, importance=5)
    got = MemoryIntelligence(m).ranked_search("same project", limit=2)
    assert got[0].key == "new"


def test_expired_memory_is_filtered(tmp_path):
    m = JarvisMemory(tmp_path / "m.json")
    m.remember("temp", "expires", MemoryScope.SHORT_TERM, ttl_seconds=1,
               updated_at=(datetime.now(timezone.utc) - timedelta(seconds=10)).isoformat())
    assert MemoryIntelligence(m).ranked_search("expires") == []


def test_context_redacts_sensitive_memory(tmp_path):
    m = JarvisMemory(tmp_path / "m.json")
    m.remember("api_key", "SECRET", MemoryScope.LONG_TERM, sensitive=True)
    context = MemoryIntelligence(m).build_context("api_key")
    assert "SECRET" not in context
    assert "sensitive memory omitted" in context


def test_purge_expired_removes_records(tmp_path):
    m = JarvisMemory(tmp_path / "m.json")
    m.remember("temp", "delete me", MemoryScope.SHORT_TERM, ttl_seconds=1,
               updated_at=(datetime.now(timezone.utc) - timedelta(seconds=10)).isoformat())
    assert MemoryIntelligence(m).purge_expired() == 0
    assert m.recall("temp", MemoryScope.SHORT_TERM) is None


def test_context_is_bounded(tmp_path):
    m = JarvisMemory(tmp_path / "m.json")
    for i in range(20):
        m.remember(f"k{i}", "x" * 500, MemoryScope.BUSINESS, importance=2)
    context = MemoryIntelligence(m).build_context("k", limit=20, max_chars=1000)
    assert len(context) <= 1000
