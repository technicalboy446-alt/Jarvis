from __future__ import annotations

from pathlib import Path

import pytest

from security import AuditLogger, PathGuard, SecurityManager, SecurityPathError, SecurityPolicy, redact_text
from tools.base_tool import Permission, ToolContext, ToolResult


def test_16_1_policy_fails_closed_for_destructive_and_admin():
    policy = SecurityPolicy()
    assert policy.check(Permission.READ)[0] is True
    assert policy.check(Permission.DESTRUCTIVE)[0] is False
    assert policy.check(Permission.ADMIN)[0] is False


def test_16_2_path_guard_blocks_escape(tmp_path: Path):
    guard = PathGuard(tmp_path / "workspace")
    inside = guard.resolve("reports/report.txt")
    assert inside.parent.name == "reports"
    with pytest.raises(SecurityPathError):
        guard.resolve("../../outside.txt")


def test_16_3_redaction_removes_common_secret_patterns():
    text = "api_key=SECRET123 authorization: Bearer ABC password=hunter2 token=XYZ"
    out = redact_text(text)
    assert "SECRET123" not in out
    assert "ABC" not in out
    assert "hunter2" not in out
    assert "XYZ" not in out
    assert out.count("[REDACTED]") == 4


def test_16_4_audit_is_append_only_jsonl(tmp_path: Path):
    path = tmp_path / "audit.jsonl"
    audit = AuditLogger(path)
    audit.record("test_event", actor="tester", result="ok", details={"api_key": "SECRET"})
    audit.record("second", actor="tester", result="info")
    lines = path.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 2
    assert '"event": "test_event"' in lines[0]


def test_16_5_manager_authorization_records_decisions(tmp_path: Path):
    manager = SecurityManager(tmp_path / "root")
    denied = manager.authorize(Permission.DESTRUCTIVE)
    allowed = manager.authorize(Permission.READ)
    assert denied.allowed is False
    assert allowed.allowed is True
    assert manager.audit.path.exists()
    assert len(manager.audit.path.read_text(encoding="utf-8").splitlines()) == 2


def test_16_6_tool_result_audit_redacts_sensitive_output(tmp_path: Path):
    manager = SecurityManager(tmp_path / "root")
    result = ToolResult(ok=False, tool="demo", error="api_key=SECRET123")
    manager.record_tool_result(result, context=ToolContext(user_id="local"))
    text = manager.audit.path.read_text(encoding="utf-8")
    assert "SECRET123" not in text
    assert "[REDACTED]" in text


def test_16_7_admin_requires_explicit_confirmation_metadata(tmp_path: Path):
    manager = SecurityManager(tmp_path / "root", policy=SecurityPolicy(max_permission=Permission.ADMIN, allow_admin=True))
    denied = manager.authorize(Permission.ADMIN, requires_confirmation=False)
    allowed = manager.authorize(Permission.ADMIN, requires_confirmation=True)
    assert denied.allowed is False
    assert allowed.allowed is True


def test_16_8_clean_package_import_and_no_external_calls(tmp_path: Path):
    manager = SecurityManager(tmp_path / "root")
    target = manager.guard_path("incoming/file.txt")
    assert target.is_absolute()
