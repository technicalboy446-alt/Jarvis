from __future__ import annotations
import hashlib
import sys
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))

from recovery.diagnostics import DiagnosticManager, DiagnosticStatus
from recovery.recovery import RecoveryManager
from recovery.updates import UpdateManager, UpdateManifest

def test_standard_diagnostics():
    report = DiagnosticManager.standard(ROOT).run()
    assert report.ok
    assert any(i.name == 'disk_free' for i in report.items)

def test_optional_import_blocked_not_failed():
    mgr = DiagnosticManager(ROOT)
    mgr.register_import('module_that_should_not_exist_for_target30', optional=True)
    report = mgr.run()
    assert report.ok
    assert report.items[0].status == DiagnosticStatus.BLOCKED

def test_runtime_dirs_recovery(tmp_path):
    result = RecoveryManager(tmp_path).ensure_runtime_dirs()
    assert result.ok
    assert (tmp_path / 'logs').is_dir()

def test_quarantine_rejects_outside(tmp_path):
    outside = tmp_path.parent / 'outside.txt'
    outside.write_text('x')
    result = RecoveryManager(tmp_path).quarantine_file(outside)
    assert not result.ok

def test_update_stage_hash_and_zip(tmp_path):
    archive = tmp_path / 'update.zip'
    with zipfile.ZipFile(archive, 'w') as zf:
        zf.writestr('version.txt', '30')
    digest = UpdateManager.sha256(archive)
    manifest = UpdateManifest('30.1', digest, 'update.zip')
    result = UpdateManager(tmp_path).stage(archive, manifest)
    assert result.ok
    assert Path(result.detail).is_file()

def test_update_rejects_wrong_hash(tmp_path):
    archive = tmp_path / 'update.zip'
    with zipfile.ZipFile(archive, 'w') as zf:
        zf.writestr('x', 'y')
    manifest = UpdateManifest('30.1', '0' * 64, 'update.zip')
    assert not UpdateManager(tmp_path).stage(archive, manifest).ok
