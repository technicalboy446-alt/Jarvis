import tempfile
from pathlib import Path
from memory.interface import JarvisMemory
from memory.types import MemoryScope

def test_scoped_roundtrip():
    with tempfile.TemporaryDirectory() as d:
        m=JarvisMemory(Path(d)/'memory.json')
        m.remember('company_rate','4.5',MemoryScope.BUSINESS,importance=5)
        m.remember('language','English',MemoryScope.PREFERENCE)
        m.remember('session_note','today',MemoryScope.SHORT_TERM,ttl_seconds=3600)
        assert m.recall('company_rate',MemoryScope.BUSINESS).value=='4.5'
        assert m.recall('language',MemoryScope.PREFERENCE).value=='English'
        assert m.recall('session_note',MemoryScope.SHORT_TERM).value=='today'

def test_search_and_forget():
    with tempfile.TemporaryDirectory() as d:
        m=JarvisMemory(Path(d)/'memory.json')
        m.remember('China company','uses net weight',MemoryScope.BUSINESS, tags=('china','weight'))
        assert m.search('net weight')[0].key=='China company'
        m.forget('China company',MemoryScope.BUSINESS)
        assert m.recall('China company',MemoryScope.BUSINESS) is None
