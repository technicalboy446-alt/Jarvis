from pathlib import Path
import pandas as pd
from data.loaders import from_rows
from data.normalization import normalize
from data.validation import validate

def test_field_aliases_and_value_normalization():
    ds=normalize(from_rows([{"Truck No":" TR-01 ","Net Weight":"36,000","Trip Date":"12/09/2026"}]))
    assert ds.rows[0]["vehicle_id"]=="TR-01"
    assert ds.rows[0]["quantity"]==36000
    assert ds.rows[0]["date"]=="2026-09-12"

def test_duplicate_detection():
    ds=normalize(from_rows([{"vehicle":"A","date":"2026-09-12"},{"vehicle":"A","date":"2026-09-12"}]))
    ds=validate(ds,key_fields=("vehicle_id","date"))
    assert any(i.code=="duplicate_key" for i in ds.issues)

def test_excel_roundtrip(tmp_path:Path):
    path=tmp_path/"test.xlsx"
    pd.DataFrame([{"Vehicle":"A","Quantity":10}]).to_excel(path,index=False)
    from data.pipeline import ingest_excel
    ds=ingest_excel(path)
    assert ds.row_count==1 and ds.rows[0]["vehicle_id"]=="A" and ds.rows[0]["quantity"]==10
