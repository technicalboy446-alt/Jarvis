import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from core.llm.providers import GeminiProvider, OllamaProvider, OpenAICompatibleProvider, build_provider
from core.llm.types import LLMRequest


def test_provider_factory():
    assert isinstance(build_provider("ollama", "llama3.2"), OllamaProvider)
    assert isinstance(build_provider("openai", "qwen", "http://localhost:1234"), OpenAICompatibleProvider)
    assert isinstance(build_provider("gemini", "gemini-3.8-flash", api_key="x"), GeminiProvider)


def test_request_is_provider_neutral():
    req = LLMRequest(messages=[{"role": "user", "content": "hello"}], max_tokens=10)
    assert req.messages[0]["content"] == "hello"
    assert req.max_tokens == 10
