from agents.base_agent import AgentRequest
from agents.manager import build_default_registry
from core.routing.router import Router, RouteRequest


def test_default_registry_contains_hermes():
    registry = build_default_registry()
    assert "hermes" in registry.names()


def test_registry_is_lazy():
    registry = build_default_registry()
    # Registration must not instantiate the heavy Hermes runtime.
    assert registry._instances == {}


def test_router_defaults_to_hermes():
    decision = Router().classify(RouteRequest("hello jarvis"))
    assert decision.target == "hermes"


def test_router_marks_data_candidate():
    decision = Router().classify(RouteRequest("read the Google Sheet trips"))
    assert decision.kind == "data_candidate"
    assert decision.target == "hermes"
