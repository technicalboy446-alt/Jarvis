from dashboard.api import dashboard_snapshot, workspace_stats, system_status

def test_dashboard_snapshot_shape():
    d = dashboard_snapshot()
    assert set(d) == {"workspace", "automation", "system"}
    assert "reports" in d["workspace"]
    assert "jobs" in d["automation"]

def test_workspace_status():
    s = workspace_stats()
    assert all(isinstance(v, int) and v >= 0 for v in s.values())

def test_system_status():
    s = system_status()
    assert all(isinstance(v, bool) for v in s.values())
