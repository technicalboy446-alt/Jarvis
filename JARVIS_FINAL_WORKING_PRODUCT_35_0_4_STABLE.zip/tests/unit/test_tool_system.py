from __future__ import annotations

from tools import (
    ExecutionPolicy,
    FunctionTool,
    Permission,
    ToolContext,
    ToolExecutor,
    ToolPolicy,
    ToolRegistry,
)


def test_registry_and_read_tool() -> None:
    registry = ToolRegistry()
    registry.register(FunctionTool(
        name="echo",
        description="Echo input",
        handler=lambda args, ctx: args["value"],
    ))
    result = ToolExecutor(registry).execute("echo", {"value": "ok"}, context=ToolContext())
    assert result.ok is True
    assert result.output == "ok"


def test_duplicate_registration_rejected() -> None:
    registry = ToolRegistry()
    tool = FunctionTool("echo", "Echo", lambda a, c: a["value"])
    registry.register(tool)
    try:
        registry.register(tool)
        raise AssertionError("duplicate should fail")
    except ValueError:
        pass


def test_destructive_tool_blocked_by_default() -> None:
    registry = ToolRegistry()
    registry.register(FunctionTool(
        name="delete_file",
        description="Delete a file",
        handler=lambda a, c: "deleted",
        permission=Permission.DESTRUCTIVE,
    ))
    result = ToolExecutor(registry).execute("delete_file", {"path": "x"})
    assert result.ok is False
    assert "Destructive tools are disabled" in (result.error or "")


def test_timeout_is_enforced() -> None:
    import time
    registry = ToolRegistry()
    registry.register(FunctionTool(
        name="slow",
        description="Slow tool",
        handler=lambda a, c: time.sleep(0.2),
    ))
    result = ToolExecutor(
        registry,
        ExecutionPolicy(timeout_seconds=0.03),
    ).execute("slow")
    assert result.ok is False
    assert "timed out" in (result.error or "")
