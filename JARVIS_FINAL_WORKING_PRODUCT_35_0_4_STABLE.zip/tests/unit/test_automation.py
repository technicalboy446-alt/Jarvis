import tempfile
from datetime import datetime
from pathlib import Path
from automation import AutomationEngine, AutomationStore, JobSpec
from scheduler.scheduler import Scheduler
from automation.alerts.alerts import AlertManager
from automation.triggers.checks import CheckRunner

def test_job_lifecycle():
    with tempfile.TemporaryDirectory() as d:
        store = AutomationStore(d); eng = AutomationEngine(store)
        eng.register_handler('report', lambda job: 'report generated')
        job = eng.add_job(JobSpec('daily report', 'report', 'daily', 'report'))
        run = eng.run(job.job_id)
        assert run.status == 'enabled' and 'report' in run.message

def test_write_guard():
    with tempfile.TemporaryDirectory() as d:
        eng = AutomationEngine(AutomationStore(d))
        try:
            eng.add_job(JobSpec('danger', 'write', 'manual', 'x', read_only=False))
        except ValueError:
            return
        raise AssertionError('write guard failed')

def test_scheduler():
    with tempfile.TemporaryDirectory() as d:
        eng = AutomationEngine(AutomationStore(d)); eng.register_handler('x', lambda j: 'ok')
        eng.add_job(JobSpec('daily', 'x', 'daily', 'x'))
        assert len(Scheduler(eng).due_jobs(datetime(2026, 9, 12, 12, 0))) == 1

def test_alerts_and_checks():
    a = AlertManager(); c = CheckRunner(a)
    out = c.run_checks([lambda: 'ok', lambda: 1/0])
    assert out[0] == 'ok' and len(a.list()) == 1
