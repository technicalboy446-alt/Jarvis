from connectors.google_sheets.client import GoogleSheetsClient

class Values: 
    def __init__(self, payload): self.payload=payload
    def get(self, **kwargs): return self
    def update(self, **kwargs): return self
    def append(self, **kwargs): return self
    def execute(self): return self.payload
class Sheets:
    def __init__(self,payload): self.payload=payload
    def values(self): return Values(self.payload)
class Service:
    def __init__(self,values_payload): self.v=values_payload
    def spreadsheets(self): return self
    def values(self): return Values(self.v)
    def get(self, **kwargs): return Values({'sheets':[{'properties':{'sheetId':1,'title':'Trips'}}]})

def test_discovery_and_read():
    c=GoogleSheetsClient(Service({'values':[['Date','Truck No','Qty'],['2026-09-01','T-1','10']]}))
    assert c.list_sheets('id')[0].title == 'Trips'
    ds=c.read_values('id','Trips')
    assert ds.rows[0]['vehicle_id']=='T-1'
    assert ds.rows[0]['quantity']==10

def test_write_requires_opt_in():
    c=GoogleSheetsClient(Service({}), allow_writes=False)
    try: c.write_values('id','Trips!A1',[[1]])
    except PermissionError: pass
    else: raise AssertionError('write must be denied by default')

def test_write_audit():
    events=[]
    c=GoogleSheetsClient(Service({'updatedRows':2}), allow_writes=True, audit=events.append)
    c.write_values('id','Trips!A1',[[1],[2]],reason='test')
    assert events and events[0].operation=='write_values' and events[0].rows_affected==2
