from __future__ import annotations
import sys
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.observability import ObservabilityManager
from core.observability.health import HealthRegistry
from core.observability.metrics import Metrics


def test_metrics_count_and_latency():
    m = Metrics()
    s = m.start(); time.sleep(0.001); m.finish(s, ok=True)
    s = m.start(); m.finish(s, ok=False)
    snap = m.snapshot()
    assert snap.started == 2
    assert snap.completed == 1
    assert snap.failed == 1
    assert snap.average_latency_ms >= 0


def test_health_registry_fail_closed_on_exception():
    h = HealthRegistry()
    h.register("ok", lambda: True)
    h.register("bad", lambda: (_ for _ in ()).throw(RuntimeError("boom")))
    r = h.run()
    assert not r.ok
    assert r.checks == {"ok": True, "bad": False}
    assert "boom" in r.errors["bad"]


def test_event_buffer_is_bounded():
    o = ObservabilityManager.create(max_events=2)
    o.emit("one"); o.emit("two"); o.emit("three")
    assert [e.name for e in o.events] == ["two", "three"]


def test_observability_snapshot_and_health():
    o = ObservabilityManager.create()
    o.health.register("runtime", lambda: True)
    started = o.metrics.start(); o.metrics.finish(started, ok=True)
    assert o.health_report().ok
    assert o.snapshot().completed == 1


def test_event_carries_request_metadata():
    o = ObservabilityManager.create()
    e = o.emit("request_completed", request_id="r-17", source="voice", status="ok", details={"duration_ms": 12})
    assert e.request_id == "r-17"
    assert e.source == "voice"
    assert e.details["duration_ms"] == 12
