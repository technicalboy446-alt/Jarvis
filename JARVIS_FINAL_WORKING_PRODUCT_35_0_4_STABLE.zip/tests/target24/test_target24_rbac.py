from pathlib import Path
import tempfile
import sys
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tools.base_tool import Permission
from security.manager import SecurityManager
from security.rbac import Role, RolePolicy


def test_default_operator_preserves_read_write():
    with tempfile.TemporaryDirectory() as td:
        sec = SecurityManager(td)
        assert sec.authorize_actor("user", Permission.READ).allowed
        assert sec.authorize_actor("user", Permission.WRITE).allowed
        assert not sec.authorize_actor("user", Permission.ADMIN).allowed


def test_viewer_is_read_only():
    with tempfile.TemporaryDirectory() as td:
        sec = SecurityManager(td, roles=RolePolicy(assignments={"alice": Role.VIEWER}))
        assert sec.authorize_actor("alice", Permission.READ).allowed
        assert not sec.authorize_actor("alice", Permission.WRITE).allowed


def test_admin_role_still_respects_confirmation_policy():
    with tempfile.TemporaryDirectory() as td:
        sec = SecurityManager(td, roles=RolePolicy(assignments={"bob": Role.ADMIN}))
        assert sec.authorize_actor("bob", Permission.ADMIN, requires_confirmation=False).allowed is False


def test_role_metadata():
    policy = RolePolicy(assignments={"alice": Role.VIEWER})
    d = policy.describe("alice")
    assert d["role"] == "viewer"
    assert d["max_permission"] == "read"


def test_unknown_actor_is_fail_safe_operator_not_admin():
    with tempfile.TemporaryDirectory() as td:
        sec = SecurityManager(td)
        assert sec.roles.role_for("unknown") is Role.OPERATOR
        assert sec.authorize_actor("unknown", Permission.ADMIN).allowed is False
