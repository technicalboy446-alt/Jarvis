from datetime import date, timedelta
from decimal import Decimal
from business.models.domain_models import Trip, Expense, Payment
from reports.builders.business_reports import trip_report, expense_report, payment_report, management_summary


def sample():
    today = date.today(); yesterday = today - timedelta(days=1)
    trips = [Trip("t1", today, "V1", quantity=Decimal("5"), unit_price=Decimal("10")), Trip("t2", today, "V2", quantity=Decimal("7"), unit_price=Decimal("9")), Trip("t3", yesterday, "V3", quantity=Decimal("2"), unit_price=Decimal("10"))]
    expenses = [Expense("e1", today, "fuel", Decimal("20")), Expense("e2", yesterday, "electricity", Decimal("5"))]
    payments = [Payment("p1", today, Decimal("40")), Payment("p2", yesterday, Decimal("10"))]
    return trips, expenses, payments


def test_trip_report():
    trips, _, _ = sample(); r = trip_report(trips, date.today(), date.today())
    assert r.summary["trip_count"] == 2
    assert r.summary["total_quantity"] == Decimal("12")
    assert r.summary["total_amount"] == Decimal("113")


def test_expense_report():
    _, expenses, _ = sample(); r = expense_report(expenses, date.today(), date.today())
    assert r.summary["expense_total"] == Decimal("20")


def test_payment_report_balance():
    _, _, payments = sample(); r = payment_report(payments, date.today(), date.today(), Decimal("100"))
    assert r.summary["period_payment_total"] == Decimal("40")
    assert r.summary["outstanding"] == Decimal("50")


def test_management_summary():
    trips, expenses, payments = sample(); r = management_summary(trips, expenses, payments, date.today(), date.today(), Decimal("100"))
    assert r.summary["net_after_expenses"] == Decimal("93")
