from pathlib import Path
from dashboard.remote import RemoteDashboardService
from dashboard.api import remote_overview, remote_health


def test_remote_overview_shape():
    data = remote_overview()
    assert set(data) == {"workspace", "automation", "system"}
    assert isinstance(data["workspace"]["reports"], int)
    assert "dashboard" in data["system"]


def test_remote_health_shape():
    data = remote_health()
    assert isinstance(data["ok"], bool)
    assert set(data["checks"]) >= {"dashboard", "workspace", "automation", "security"}


def test_workspace_path_is_contained(tmp_path: Path):
    service = RemoteDashboardService(tmp_path)
    (tmp_path / "workspace").mkdir()
    try:
        service.workspace_files("../escape")
    except ValueError:
        pass
    else:
        raise AssertionError("path escape must be rejected")


def test_reports_listing_is_bounded(tmp_path: Path):
    service = RemoteDashboardService(tmp_path)
    reports = tmp_path / "workspace" / "reports"
    reports.mkdir(parents=True)
    for i in range(8):
        (reports / f"r{i}.json").write_text("{}", encoding="utf-8")
    items = service.reports_list(limit=3)
    assert len(items) == 3
    assert all("path" in item and item["path"].startswith("reports/") for item in items)


def test_job_and_run_views(tmp_path: Path):
    service = RemoteDashboardService(tmp_path)
    service.automation.mkdir(parents=True)
    (service.automation / "jobs.json").write_text("[]", encoding="utf-8")
    (service.automation / "runs.jsonl").write_text('{"job_id":"x","status":"ok"}\n', encoding="utf-8")
    assert service.jobs() == []
    assert service.runs(limit=5)[0]["job_id"] == "x"


def test_remote_http_routes_registered():
    from dashboard.server import DashboardServer
    app = DashboardServer().app
    routes = {getattr(r, "path", "") for r in app.routes}
    expected = {
        "/api/remote/overview",
        "/api/remote/reports",
        "/api/remote/jobs",
        "/api/remote/runs",
        "/api/remote/health",
        "/api/remote/command",
    }
    assert expected <= routes
