from pathlib import Path
from security.manager import SecurityManager
from notifications import NotificationManager, NotificationRequest, MemoryAdapter, MessageTemplates


def test_memory_delivery(tmp_path: Path):
    mgr = NotificationManager(tmp_path, security=SecurityManager(tmp_path))
    adapter = MemoryAdapter(); mgr.register(adapter)
    r = mgr.send(NotificationRequest(channel="memory", recipient="user", text="hello"))
    assert r.ok and r.status == "sent" and len(adapter.messages) == 1


def test_deduplication(tmp_path: Path):
    mgr = NotificationManager(tmp_path, security=SecurityManager(tmp_path))
    adapter = MemoryAdapter(); mgr.register(adapter)
    req = NotificationRequest(channel="memory", recipient="user", text="hello", notification_id="same-id")
    first = mgr.send(req); second = mgr.send(req)
    assert first.ok and second.ok and second.status == "deduplicated" and len(adapter.messages) == 1


def test_retry_on_failure(tmp_path: Path):
    class Failing(MemoryAdapter):
        channel = "flaky"
        def __init__(self): super().__init__(); self.calls = 0
        def send(self, recipient, *, subject, text, metadata):
            self.calls += 1
            if self.calls < 3: raise RuntimeError("temporary")
            return super().send(recipient, subject=subject, text=text, metadata=metadata)
    mgr = NotificationManager(tmp_path, security=SecurityManager(tmp_path), backoff_seconds=0)
    a = Failing(); mgr.register(a)
    r = mgr.send(NotificationRequest(channel="flaky", recipient="user", text="hello"))
    assert r.ok and r.attempts == 3 and a.calls == 3


def test_unknown_channel_fails_closed(tmp_path: Path):
    mgr = NotificationManager(tmp_path)
    r = mgr.send(NotificationRequest(channel="unknown", recipient="user", text="x"))
    assert not r.ok and r.status == "unsupported"


def test_rbac_blocks_viewer(tmp_path: Path):
    from security.rbac import Role, RolePolicy
    roles = RolePolicy(default_role=Role.VIEWER)
    security = SecurityManager(tmp_path, roles=roles)
    mgr = NotificationManager(tmp_path, security=security)
    mgr.register(MemoryAdapter())
    r = mgr.send(NotificationRequest(channel="memory", recipient="user", text="x", actor="viewer"))
    assert not r.ok and r.status == "denied"


def test_bilingual_template():
    msg = MessageTemplates.management_report(period="daily", summary="Trips: 5", arabic="الرحلات: 5")
    assert "Trips: 5" in msg.english and "الرحلات: 5" in msg.arabic and "العربية" in msg.combined
