from __future__ import annotations

from pathlib import Path

from agents.base_agent import AgentResponse
from agents.manager import AgentManager
from agents.registry import AgentRegistry
from connectors.registry import ConnectorRegistry
from core.orchestration.context import OrchestrationRequest
from core.production.runtime import ProductionRuntime
from notifications.adapters import NotificationAdapter
from notifications.models import NotificationRequest


class EchoAgent:
    def __init__(self, name: str = "echo"):
        self.name = name

    def run(self, request):
        return AgentResponse(agent=self.name, text=f"processed:{request.text}", metadata={"request_id": request.metadata["request_id"]})


def make_runtime(tmp_path: Path) -> ProductionRuntime:
    registry = AgentRegistry()
    registry.register("hermes", EchoAgent)
    agents = AgentManager(registry)
    return ProductionRuntime.build(tmp_path, agent_manager=agents, connector_registry=ConnectorRegistry())


def test_end_to_end_request_preserves_request_id_and_source(tmp_path):
    runtime = make_runtime(tmp_path)
    request = OrchestrationRequest("hello", source="voice", user_id="operator")
    result = runtime.handle(request)
    assert result.ok is True
    assert result.source == "voice"
    assert result.request_id == request.request_id
    assert result.text == "processed:hello"


def test_runtime_exposes_health_and_diagnostics(tmp_path):
    runtime = make_runtime(tmp_path)
    health = runtime.health()
    assert "diagnostics" in health
    assert "dashboard" in health
    assert "connectors" in health
    assert set(health["dashboard"]["checks"]) >= {"workspace", "reports", "automation", "security", "observability"}


class DummyAdapter(NotificationAdapter):
    channel = "dummy"
    def send(self, recipient: str, *, subject: str, text: str, metadata: dict):
        return "dummy-1"


def test_notification_path_uses_composed_runtime(tmp_path):
    runtime = make_runtime(tmp_path)
    runtime.notifications.register(DummyAdapter())
    result = runtime.notify(NotificationRequest(
        notification_id="t31-1",
        channel="dummy",
        recipient="local",
        text="hello",
        actor="jarvis",
    ))
    assert result.ok is True
    assert result.status == "sent"


def test_orchestration_and_dashboard_share_workspace(tmp_path):
    runtime = make_runtime(tmp_path)
    assert runtime.dashboard.base_dir == tmp_path.resolve()
    assert runtime.config.root == tmp_path.resolve()


def test_diagnostics_is_safe_when_optional_components_are_missing(tmp_path):
    runtime = make_runtime(tmp_path)
    report = runtime.diagnose()
    assert report.items
    assert all(item.status.value in {"pass", "blocked", "fail"} for item in report.items)
