from __future__ import annotations
import json
from pathlib import Path

from agents.base_agent import AgentRequest, AgentResponse
from agents.manager import AgentManager
from agents.registry import AgentRegistry
from core.orchestration import OrchestrationRequest, Orchestrator
from core.routing.router import Router
from security.manager import SecurityManager

class FakeAgent:
    name = "fake"
    description = "test"
    def run(self, request: AgentRequest) -> AgentResponse:
        return AgentResponse(text=f"echo:{request.text}", agent=self.name)

def build_orchestrator(tmp_path: Path) -> tuple[Orchestrator, Path]:
    registry = AgentRegistry()
    registry.register("hermes", FakeAgent)
    agent_manager = AgentManager(registry)
    audit_path = tmp_path / "audit.jsonl"
    security = SecurityManager(tmp_path / "workspace", audit_path=audit_path)
    return Orchestrator(router=Router(), agents=agent_manager, security=security), audit_path

def test_text_and_voice_share_same_execution_path(tmp_path: Path):
    orchestrator, _ = build_orchestrator(tmp_path)
    text = orchestrator.handle(OrchestrationRequest("hello", source="text"))
    voice = orchestrator.handle(OrchestrationRequest("hello", source="voice"))
    assert text.ok and voice.ok
    assert text.text == voice.text == "echo:hello"
    assert text.agent == voice.agent == "fake"
    assert text.route_target == voice.route_target == "hermes"

def test_empty_request_fails_cleanly(tmp_path: Path):
    orchestrator, _ = build_orchestrator(tmp_path)
    result = orchestrator.handle(OrchestrationRequest("  "))
    assert not result.ok
    assert "empty" in (result.error or "").lower()

def test_router_metadata_reaches_agent(tmp_path: Path):
    orchestrator, _ = build_orchestrator(tmp_path)
    result = orchestrator.handle(OrchestrationRequest("check invoice", metadata={"project": "demo"}))
    assert result.ok

def test_audit_has_route_and_completion(tmp_path: Path):
    orchestrator, audit_path = build_orchestrator(tmp_path)
    result = orchestrator.handle(OrchestrationRequest("status"))
    assert result.ok
    rows = [json.loads(line) for line in audit_path.read_text().splitlines() if line.strip()]
    events = [row["event"] for row in rows]
    assert "orchestration_routed" in events
    assert "orchestration_completed" in events

def test_agent_failure_is_normalized(tmp_path: Path):
    registry = AgentRegistry()
    class BrokenAgent:
        name = "hermes"
        description = "broken"
        def run(self, request: AgentRequest) -> AgentResponse:
            raise RuntimeError("boom")
    registry.register("hermes", BrokenAgent)
    security = SecurityManager(tmp_path / "workspace")
    orchestrator = Orchestrator(router=Router(), agents=AgentManager(registry), security=security)
    result = orchestrator.handle(OrchestrationRequest("hello"))
    assert not result.ok
    assert result.error == "boom"
