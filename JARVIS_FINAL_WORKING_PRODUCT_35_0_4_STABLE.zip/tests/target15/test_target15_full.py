from __future__ import annotations

from interface.voice import VoiceManager, VoiceSessionState


class FakeUI:
    def __init__(self):
        self.states = []
        self.logs = []

    def set_state(self, state):
        self.states.append(state)

    def write_log(self, text):
        self.logs.append(text)


class FakeRuntime:
    def __init__(self):
        self.ui = FakeUI()
        self.commands = []
        self.spoken = []
        self.interrupts = 0
        self.reconnects = []
        self.tool_results = []

    def _on_text_command(self, text):
        self.commands.append(text)

    def speak(self, text):
        self.spoken.append(text)

    def interrupt(self):
        self.interrupts += 1

    def request_reconnect(self, keep_context=True, reason=""):
        self.reconnects.append((keep_context, reason))


def test_15_2_canonical_dispatch_uses_existing_router_path():
    runtime = FakeRuntime()
    manager = VoiceManager(runtime)
    manager.activate()
    assert manager.dispatch("show today's trips") is True
    assert runtime.commands == ["show today's trips"]


def test_15_3_agent_tool_and_data_requests_keep_same_entry_path():
    runtime = FakeRuntime()
    manager = VoiceManager(runtime)
    manager.activate()
    for text in ("read the Google Sheet", "run the report", "ask the business question"):
        assert manager.dispatch(text) is True
    assert runtime.commands == [
        "read the Google Sheet",
        "run the report",
        "ask the business question",
    ]


def test_15_4_thinking_and_listening_state_are_available_for_business_qa_reporting():
    runtime = FakeRuntime()
    manager = VoiceManager(runtime)
    manager.activate()
    manager.set_thinking()
    assert manager.status().state == VoiceSessionState.THINKING.value
    manager.set_listening()
    assert manager.status().state == VoiceSessionState.LISTENING.value


def test_15_5_confirmation_is_observed_not_auto_confirmed():
    runtime = FakeRuntime()
    manager = VoiceManager(runtime)
    manager.activate()
    assert manager.pending_confirmation() == ""
    assert manager.confirmation_pending() is False
    marker = manager.handle_tool_result("[CONFIRMATION_PENDING] waiting for HUD")
    assert marker.startswith("[CONFIRMATION_PENDING]")
    assert manager.status().state == VoiceSessionState.LISTENING.value


def test_15_6_stt_failure_is_captured_and_empty_transcript_returned():
    class BrokenSTT:
        def transcribe(self, audio):
            raise RuntimeError("microphone decoding failed")

    manager = VoiceManager(FakeRuntime())
    manager.input.stt = BrokenSTT()
    assert manager.input.transcribe(b"pcm") == ""
    assert "microphone decoding failed" in manager.input.state.error


def test_15_6_tts_failure_uses_text_fallback():
    class BrokenRuntime(FakeRuntime):
        def speak(self, text):
            raise RuntimeError("speaker unavailable")

    runtime = BrokenRuntime()
    manager = VoiceManager(runtime)
    assert manager.speak("fallback response") is False
    assert runtime.ui.logs[-1] == "JARVIS: fallback response"


def test_15_6_interrupt_and_reconnect_preserve_existing_runtime_behaviour():
    runtime = FakeRuntime()
    manager = VoiceManager(runtime)
    manager.activate()
    assert manager.interrupt() is True
    assert manager.request_reconnect() is True
    assert runtime.interrupts == 1
    assert runtime.reconnects == [(True, "voice")]


def test_15_7_deactivation_removes_active_voice_session():
    manager = VoiceManager(FakeRuntime())
    manager.activate()
    assert manager.status().active is True
    manager.deactivate()
    assert manager.status().active is False
    assert manager.status().state == VoiceSessionState.SLEEPING.value


def test_15_7_wake_gate_can_disable_and_reenable():
    manager = VoiceManager(FakeRuntime())
    manager.activate()
    manager.enable_wake(False)
    assert manager.status().active is False
    manager.enable_wake(True)
    manager.activate()
    assert manager.status().active is True


def test_15_8_status_exposes_input_output_and_session_diagnostics():
    runtime = FakeRuntime()
    manager = VoiceManager(runtime)
    manager.activate()
    manager.dispatch("status")
    manager.speak("diagnostic output")
    status = manager.status()
    assert status.last_input == "status"
    assert status.last_output == "diagnostic output"
    assert status.last_error == ""
