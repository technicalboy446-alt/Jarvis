from __future__ import annotations

from interface.voice import VoiceManager, VoiceSessionState


class FakeUI:
    def __init__(self):
        self.states = []
        self.logs = []

    def set_state(self, state):
        self.states.append(state)

    def write_log(self, text):
        self.logs.append(text)


class FakeRuntime:
    def __init__(self):
        self.ui = FakeUI()
        self.commands = []
        self.spoken = []
        self.interrupts = 0
        self.reconnects = []

    def _on_text_command(self, text):
        self.commands.append(text)

    def speak(self, text):
        self.spoken.append(text)

    def interrupt(self):
        self.interrupts += 1

    def request_reconnect(self, keep_context=True, reason=""):
        self.reconnects.append((keep_context, reason))


def test_voice_text_parity_uses_normal_command_path():
    runtime = FakeRuntime()
    manager = VoiceManager(runtime)
    manager.activate()
    assert manager.handle_text("What is 2 plus 2?") is True
    assert runtime.commands == ["What is 2 plus 2?"]
    assert manager.status().state == VoiceSessionState.LISTENING.value


def test_interrupt_delegates_to_existing_runtime():
    runtime = FakeRuntime()
    manager = VoiceManager(runtime)
    manager.activate()
    assert manager.interrupt() is True
    assert runtime.interrupts == 1
    assert manager.status().interrupted is True


def test_tts_uses_existing_runtime_and_fallbacks():
    runtime = FakeRuntime()
    manager = VoiceManager(runtime)
    assert manager.speak("Hello") is True
    assert runtime.spoken == ["Hello"]

    class Broken:
        ui = runtime.ui
        def speak(self, text):
            raise RuntimeError("tts down")

    manager.bind_runtime(Broken())
    assert manager.speak("Fallback") is False
    assert runtime.ui.logs[-1] == "JARVIS: Fallback"


def test_confirmation_pending_is_not_auto_confirmed():
    runtime = FakeRuntime()
    manager = VoiceManager(runtime)
    manager.activate()
    marker = "[CONFIRMATION_PENDING] confirm it on the HUD"
    assert manager.handle_tool_result(marker) == marker
    assert manager.status().state == VoiceSessionState.LISTENING.value


def test_reconnect_preserves_context_by_default():
    runtime = FakeRuntime()
    manager = VoiceManager(runtime)
    assert manager.request_reconnect() is True
    assert runtime.reconnects == [(True, "voice")]
