import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def test_root_layout_and_version():
    assert (ROOT / 'main.py').is_file()
    assert (ROOT / 'requirements.txt').is_file()
    assert (ROOT / 'scripts' / 'run_windows.bat').is_file()
    assert (ROOT / 'scripts' / 'run_unix.sh').is_file()
    assert (ROOT / 'VERSION').read_text().strip() == '35.0.4'

def test_manifest_matches_layout():
    data = json.loads((ROOT / 'RELEASE_MANIFEST.json').read_text())
    assert data['release'] == '35.0.4'
    assert data['entrypoint'] == 'main.py'
    assert all((ROOT / p).is_file() for p in data['launchers'])
    assert all((ROOT / p).is_file() for p in data['installers'])

def test_no_nested_src_release_path():
    assert not (ROOT / 'src').exists()


def test_no_credential_files_shipped():
    banned = {'api_keys.json', 'token.json', 'credentials.json'}
    for p in ROOT.rglob('*'):
        if p.is_file():
            assert p.name not in banned
