from pathlib import Path

from actions import google_sheets as gs


def test_google_sheets_tool_reads_configured_spreadsheet(monkeypatch, tmp_path):
    cfg = tmp_path / "config"
    cfg.mkdir()
    (cfg / "google_sheets.json").write_text(
        '{"spreadsheet_id":"sheet123","credentials_path":"creds.json","token_path":"token.json","allow_writes":false}',
        encoding="utf-8",
    )
    monkeypatch.setattr(gs, "_base_dir", lambda: tmp_path)

    class Ref:
        def __init__(self, title): self.title = title
    class FakeClient:
        def list_sheets(self, spreadsheet_id):
            assert spreadsheet_id == "sheet123"
            return [Ref("Trips"), Ref("Expenses")]
    monkeypatch.setattr(gs, "_client", lambda cfg: FakeClient())

    out = gs.google_sheets({"operation":"list_sheets"})
    assert "Trips" in out
    assert "Expenses" in out
