import sys
import types


def test_close_app_passes_explicit_target(monkeypatch):
    fake_pyautogui = types.SimpleNamespace(
        FAILSAFE=True,
        PAUSE=0.05,
        hotkey=lambda *a, **k: None,
        press=lambda *a, **k: None,
    )
    monkeypatch.setitem(sys.modules, 'pyautogui', fake_pyautogui)
    import importlib
    cs = importlib.import_module('actions.computer_settings')
    monkeypatch.setattr(cs, '_OS', 'Windows')
    monkeypatch.setattr(cs, '_PYAUTOGUI', True)
    calls = []

    class GW:
        @staticmethod
        def getAllWindows():
            class W:
                title = 'Untitled - Notepad'
                def close(self):
                    calls.append('close')
            return [W()]

    monkeypatch.setitem(sys.modules, 'pygetwindow', GW)
    cs.close_app('Notepad')
    assert calls == ['close']
