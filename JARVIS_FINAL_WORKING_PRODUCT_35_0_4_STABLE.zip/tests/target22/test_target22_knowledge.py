from knowledge import KnowledgeDocument, KnowledgeManager
from core.orchestration.orchestrator import Orchestrator
from core.orchestration.context import OrchestrationRequest


def test_index_and_search_grounded():
    k = KnowledgeManager()
    k.add_document(KnowledgeDocument("d1", "sheet:trips", "Trip Ledger", "Truck 101 delivered 25 tonnes to China project on 2026-09-12."))
    r = k.search("China project tonnes", limit=3)
    assert r.grounded is True
    assert r.hits[0].chunk.doc_id == "d1"


def test_bounded_grounding_context():
    k = KnowledgeManager()
    k.add_document(KnowledgeDocument("d1", "file", "A", "alpha " * 600))
    ctx = k.grounded_context("alpha", max_chars=500)
    assert len(ctx) <= 500


def test_remove_and_stats():
    k = KnowledgeManager()
    k.add_document(KnowledgeDocument("d1", "file", "A", "hello world"))
    assert k.stats()["documents"] == 1
    assert k.remove("d1") > 0
    assert k.stats() == {"documents": 0, "chunks": 0}


def test_no_match_is_not_grounded():
    k = KnowledgeManager()
    k.add_document(KnowledgeDocument("d1", "file", "A", "invoice payment"))
    r = k.search("unrelated quantum topic")
    assert r.grounded is False
    assert r.reason == "no_match"


def test_orchestrator_can_attach_grounding_without_changing_router():
    class StubRouter:
        def classify(self, request):
            return type("Decision", (), {"kind":"agent", "target":"demo", "confidence":1.0})()
    class StubAgents:
        def __init__(self): self.last=None
        def run(self, target, req):
            self.last=req
            return type("Resp", (), {"text":"done", "agent":"demo", "metadata":{}})()
    class Audit:
        def record(self,*a,**k): pass
    class Sec:
        audit=Audit()
    k=KnowledgeManager(); k.add_document(KnowledgeDocument("d1","memo","Ledger","The project balance is 45000 OMR."))
    a=StubAgents(); o=Orchestrator(router=StubRouter(), agents=a, security=Sec(), knowledge=k)
    result=o.handle(OrchestrationRequest("tell me the balance", metadata={"grounding_query":"project balance"}))
    assert result.ok is True
    assert "45000 OMR" in a.last.metadata["grounding_context"]


def test_empty_query_safe():
    k=KnowledgeManager()
    r=k.search("")
    assert r.grounded is False
    assert r.reason == "empty_query"
