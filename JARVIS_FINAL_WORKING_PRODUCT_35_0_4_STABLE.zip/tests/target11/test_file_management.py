import tempfile
from pathlib import Path

from workspace.file_manager import WorkspaceManager


def test_ingest_and_dedupe():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "workspace"
        source = Path(tmp) / "Daily Report!.csv"
        source.write_text("a,b\n1,2\n", encoding="utf-8")
        wm = WorkspaceManager(root)
        first = wm.ingest(source)
        second = wm.ingest(source)
        assert first.category == "incoming"
        assert second.name != first.name
        assert (root / first.path).exists()
        assert (root / second.path).exists()


def test_move_and_archive():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "workspace"
        source = Path(tmp) / "statement.pdf"
        source.write_bytes(b"statement")
        wm = WorkspaceManager(root)
        wm.ingest(source)
        moved = wm.move("statement.pdf", "incoming", "processed")
        assert moved.category == "processed"
        archived = wm.archive("statement.pdf")
        assert archived.category == "archives"
        assert (root / "archives" / "statement.pdf").exists()


def test_search_and_classification():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "workspace"
        source = Path(tmp) / "China Trip Report.csv"
        source.write_text("trip,qty\n1,5\n", encoding="utf-8")
        wm = WorkspaceManager(root)
        wm.ingest(source)
        assert wm.search("china")[0].name == "China Trip Report.csv"
        assert wm.classify("monthly report.xlsx") == "reports"
        assert wm.classify("payment statement.pdf") == "statements"
