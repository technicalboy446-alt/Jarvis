from __future__ import annotations

import json
from pathlib import Path

from connectors import ConnectorCall, ConnectorGateway, ConnectorRegistry
from tools.base_tool import Permission
from security.manager import SecurityManager

from core.observability import ObservabilityManager


class FakeConnector:
    name = "demo"
    description = "demo connector"
    permission = Permission.READ
    requires_confirmation = False
    capabilities = ("echo", "health")

    def health(self) -> bool:
        return True

    def invoke(self, operation: str, arguments):
        if operation != "echo":
            raise ValueError("unsupported")
        return {"echo": arguments.get("text"), "api_key": "SECRET-1234567890"}


class BrokenConnector(FakeConnector):
    name = "broken"
    def health(self) -> bool:
        raise RuntimeError("offline")

    def invoke(self, operation: str, arguments):
        raise RuntimeError("upstream failed with api_key=SECRET-ABCDEFGHIJK")


def build(tmp_path: Path):
    registry = ConnectorRegistry()
    registry.register(FakeConnector())
    registry.register(BrokenConnector())
    security = SecurityManager(tmp_path / "workspace", audit_path=tmp_path / "audit.jsonl")
    obs = ObservabilityManager.create()
    return ConnectorGateway(registry, security, obs), security, obs


def test_registry_discovers_capabilities(tmp_path: Path):
    gateway, _, _ = build(tmp_path)
    caps = gateway.capabilities()
    assert [c["name"] for c in caps] == ["broken", "demo"]
    assert "echo" in caps[1]["capabilities"]


def test_successful_connector_call_is_audited_and_observed(tmp_path: Path):
    gateway, _, obs = build(tmp_path)
    result = gateway.invoke(ConnectorCall("demo", "echo", {"text": "hello"}, request_id="r19", source="voice"))
    assert result.ok
    assert result.output["echo"] == "hello"
    assert any(e.name == "connector_completed" for e in obs.events)
    rows = [json.loads(line) for line in (tmp_path / "audit.jsonl").read_text().splitlines() if line.strip()]
    completed = [row for row in rows if row["event"] == "connector_completed"][-1]
    assert "SECRET-1234567890" not in json.dumps(completed)


def test_unknown_connector_fails_closed(tmp_path: Path):
    gateway, _, _ = build(tmp_path)
    result = gateway.invoke(ConnectorCall("missing", "echo", {}))
    assert not result.ok
    assert "Unknown JARVIS connector" in (result.error or "")


def test_health_failures_are_false_not_raised(tmp_path: Path):
    gateway, _, obs = build(tmp_path)
    result = gateway.health()
    assert result == {"broken": False, "demo": True}
    assert any(e.name == "connector_health_failed" for e in obs.events)


def test_connector_failure_is_normalized_and_redacted(tmp_path: Path):
    gateway, _, _ = build(tmp_path)
    result = gateway.invoke(ConnectorCall("broken", "echo", {}))
    assert not result.ok
    assert "SECRET-ABCDEFGHIJK" not in (result.error or "")
    assert result.error
