from __future__ import annotations

import pytest

from core.llm.router import ProviderRouter, RouteSpec
from core.llm.types import LLMRequest, LLMResponse


class FakeProvider:
    def __init__(self, name: str, fail: bool = False):
        self.name = name
        self.fail = fail
        self.calls = 0

    def complete(self, request):
        self.calls += 1
        if self.fail:
            raise RuntimeError("temporary outage")
        return LLMResponse(content=f"ok:{self.name}", provider=self.name, model=request.model or "m")

    def stream(self, request):
        self.calls += 1
        if self.fail:
            raise RuntimeError("temporary outage")
        yield type("E", (), {"type":"sentence", "text":f"ok:{self.name}", "content":"", "tool_calls":[], "raw":None})()
        yield type("E", (), {"type":"done", "text":"", "content":f"ok:{self.name}", "tool_calls":[], "raw":None})()


def test_route_falls_back(monkeypatch):
    first = FakeProvider("primary", fail=True)
    second = FakeProvider("fallback")
    mapping = {"primary": first, "fallback": second}
    monkeypatch.setattr(ProviderRouter, "_provider", staticmethod(lambda spec: mapping[spec.provider]))
    router = ProviderRouter([RouteSpec("primary", "m"), RouteSpec("fallback", "m")])
    result = router.complete(LLMRequest(messages=[{"role":"user","content":"x"}]))
    assert result.content == "ok:fallback"
    assert first.calls == 1 and second.calls == 1


def test_stream_does_not_splice_after_emission(monkeypatch):
    first = FakeProvider("primary", fail=True)
    second = FakeProvider("fallback")
    mapping = {"primary": first, "fallback": second}
    monkeypatch.setattr(ProviderRouter, "_provider", staticmethod(lambda spec: mapping[spec.provider]))
    router = ProviderRouter([RouteSpec("primary", "m"), RouteSpec("fallback", "m")])
    events = list(router.stream(LLMRequest(messages=[{"role":"user","content":"x"}])))
    assert any(e.content == "ok:fallback" for e in events)


def test_routes_are_independent():
    router = ProviderRouter([RouteSpec("ollama", "m"), RouteSpec("openai", "m")])
    assert [r.provider for r in router.routes()] == ["ollama", "openai"]


def test_route_key_and_cooldown(monkeypatch):
    router = ProviderRouter([RouteSpec("p", "m", cooldown_seconds=5)])
    spec = router.routes()[0]
    router._record_failure(spec)
    assert not router._available(spec)
    router._cooldown_until[router._key(spec)] = 0
    assert router._available(spec)


def test_public_facade_imports_router():
    import core.llm as llm
    assert hasattr(llm, "ProviderRouter")
