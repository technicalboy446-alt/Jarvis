from __future__ import annotations

import json
import os
import time
from pathlib import Path

from core.performance import PerformanceManager
from dashboard.server import DashboardServer, TOKEN_TTL_SECONDS, DEVICE_TTL_SECONDS
from security.audit import AuditLogger
from security.redaction import redact_text

def test_redaction_handles_json_like_keys():
    text = '{"gemini_api_key":"SECRET123", "password":"P@ssword", "token":"abc"}'
    out = redact_text(text)
    assert "SECRET123" not in out
    assert "P@ssword" not in out
    assert "abc" not in out
    assert "[REDACTED]" in out

def test_audit_log_is_private(tmp_path: Path):
    p = tmp_path / "audit.jsonl"
    AuditLogger(p).record("x", details={"password": "SECRET"})
    # POSIX permission bits are meaningful on Unix; Windows exposes different semantics.
    if os.name != "nt":
        assert (p.stat().st_mode & 0o077) == 0
    line = p.read_text(encoding="utf-8").strip()
    assert json.loads(line)["event"] == "x"

def test_performance_guard_enters_safe_mode(monkeypatch):
    class VM:
        total = 8 * 1024**3
        available = 200 * 1024**2
        percent = 98.0
    import core.performance.manager as m
    class Psutil:
        @staticmethod
        def virtual_memory():
            return VM()
    monkeypatch.setattr(m, "psutil", Psutil)
    pm = PerformanceManager()
    assert pm.pressure == "critical"
    assert pm.concurrency_limit() == 1
    assert pm.allow() is False

def test_dashboard_token_expiry_and_device_rotation():
    s = DashboardServer()
    key = s.new_key(60)
    token = s._issue_token(key)
    assert token in s._tokens
    s._token_expiry[token] = time.time() - 1
    s._prune_tokens()
    assert token not in s._tokens
    dev = "dev-1"
    s._device_sessions[dev] = {"session_key": "old", "expires": time.time() + DEVICE_TTL_SECONDS}
    old = s._device_sessions[dev]["session_key"]
    s._device_sessions[dev]["session_key"] = "new"
    assert s._device_sessions[dev]["session_key"] != old
    assert TOKEN_TTL_SECONDS > 0
