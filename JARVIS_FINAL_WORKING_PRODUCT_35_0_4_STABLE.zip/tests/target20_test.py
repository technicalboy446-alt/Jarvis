import tempfile
from automation import AutomationEngine, AutomationStore, JobSpec
from automation.runtime import WorkflowRuntime


def test_retry_then_success():
    with tempfile.TemporaryDirectory() as d:
        store = AutomationStore(d)
        eng = AutomationEngine(store)
        state = {"n": 0}
        def handler(job):
            state["n"] += 1
            if state["n"] < 2:
                raise RuntimeError("temporary")
            return "ok"
        eng.register_handler("x", handler)
        job = eng.add_job(JobSpec("retry", "test", "manual", "x", metadata={"retry": {"max_attempts": 2, "backoff_seconds": 0}}))
        run = WorkflowRuntime(eng, store).run(job.job_id)
        assert run.status == "enabled"
        assert state["n"] == 2


def test_idempotency_skips_duplicate():
    with tempfile.TemporaryDirectory() as d:
        store = AutomationStore(d)
        eng = AutomationEngine(store)
        state = {"n": 0}
        eng.register_handler("x", lambda job: state.__setitem__("n", state["n"] + 1) or "ok")
        job = eng.add_job(JobSpec("once", "test", "manual", "x"))
        rt = WorkflowRuntime(eng, store)
        a = rt.run(job.job_id, scheduled_for="2026-09-12T12:00")
        b = rt.run(job.job_id, scheduled_for="2026-09-12T12:00")
        assert a.status == "enabled" and b.status == "enabled"
        assert state["n"] == 1
        assert "duplicate" in b.message.lower()


def test_failure_creates_alert():
    with tempfile.TemporaryDirectory() as d:
        store = AutomationStore(d)
        eng = AutomationEngine(store)
        eng.register_handler("x", lambda job: 1 / 0)
        job = eng.add_job(JobSpec("bad", "test", "manual", "x", metadata={"retry": {"max_attempts": 1}}))
        rt = WorkflowRuntime(eng, store)
        run = rt.run(job.job_id)
        assert run.status == "failed"
        assert len(rt.alerts.list()) == 1


def test_status_and_concurrency_state():
    with tempfile.TemporaryDirectory() as d:
        store = AutomationStore(d)
        eng = AutomationEngine(store)
        eng.register_handler("x", lambda job: "ok")
        job = eng.add_job(JobSpec("one", "test", "manual", "x"))
        rt = WorkflowRuntime(eng, store, max_concurrent=1)
        rt.run(job.job_id)
        s = rt.status()
        assert s["running_count"] == 0 and s["max_concurrent"] == 1


def test_write_guard_remains_active():
    with tempfile.TemporaryDirectory() as d:
        store = AutomationStore(d)
        eng = AutomationEngine(store)
        job = JobSpec("danger", "write", "manual", "x", read_only=False)
        try:
            eng.add_job(job)
        except ValueError:
            return
        raise AssertionError("write guard failed")
