from datetime import date
from decimal import Decimal

from business.models.domain_models import Expense, Payment, Trip
from core.question_answering import QuestionAnsweringEngine


def make_engine():
    trips = [
        Trip("t1", date.today(), "V1", quantity=Decimal("5")),
        Trip("t2", date.today(), "V2", quantity=Decimal("7")),
        Trip("t3", date(2026, 1, 1), "V3", quantity=Decimal("11")),
    ]
    expenses = [Expense("e1", date.today(), "fuel", Decimal("25"))]
    payments = [Payment("p1", date.today(), Decimal("40"))]
    return QuestionAnsweringEngine(trips=trips, expenses=expenses, payments=payments, invoiced_amount=Decimal("100"))


def test_trip_count_today():
    result = make_engine().ask("How many trips did we do today?")
    assert result.plan.intent == "trip_count"
    assert result.value == 2
    assert result.grounded is True


def test_quantity_today():
    result = make_engine().ask("How much material was delivered today?")
    assert result.plan.intent == "trip_quantity"
    assert result.value == Decimal("12")


def test_expenses():
    result = make_engine().ask("What were today's expenses?")
    assert result.plan.intent == "expenses_total"
    assert result.value == Decimal("25")


def test_balance():
    result = make_engine().ask("How much is still unpaid?")
    assert result.plan.intent == "balance"
    assert result.value == Decimal("60")


def test_unknown_is_safe():
    result = make_engine().ask("Tell me something")
    assert result.grounded is False
    assert result.plan.needs_clarification is True
