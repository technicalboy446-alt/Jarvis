from pathlib import Path
import json
from multimodal import AttachmentExtractor, AttachmentKind, MultimodalManager
from core.orchestration.context import OrchestrationRequest


def test_text_and_csv_extraction(tmp_path: Path):
    txt = tmp_path / 'note.txt'; txt.write_text('hello JARVIS', encoding='utf-8')
    csv = tmp_path / 'data.csv'; csv.write_text('a,b\n1,2\n', encoding='utf-8')
    ex = AttachmentExtractor()
    assert ex.extract(txt).text == 'hello JARVIS'
    result = ex.extract(csv)
    assert result.ok and '1 | 2' in result.text


def test_docx_extraction(tmp_path: Path):
    from zipfile import ZipFile, ZIP_DEFLATED
    p = tmp_path / 'x.docx'
    xml = '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:p><w:r><w:t>Hello document</w:t></w:r></w:p></w:document>'
    with ZipFile(p, 'w', ZIP_DEFLATED) as z: z.writestr('word/document.xml', xml)
    r = AttachmentExtractor().extract(p)
    assert r.ok and 'Hello document' in r.text


def test_image_metadata(tmp_path: Path):
    from PIL import Image
    p = tmp_path / 'x.png'; Image.new('RGB', (20, 10)).save(p)
    r = AttachmentExtractor().extract(p)
    assert r.ok and r.attachment.kind == AttachmentKind.IMAGE and r.metadata['width'] == 20


def test_manager_builds_evidence_and_context(tmp_path: Path):
    p = tmp_path / 'note.md'; p.write_text('# Title\ncontent', encoding='utf-8')
    prepared = MultimodalManager().prepare([str(p)])
    assert prepared.extracted_text.startswith('[note.md]')
    assert prepared.evidence[0]['kind'] == 'text'


def test_request_accepts_attachments():
    req = OrchestrationRequest(text='summarize', attachments=['/tmp/example.txt'])
    assert req.attachments == ['/tmp/example.txt']
