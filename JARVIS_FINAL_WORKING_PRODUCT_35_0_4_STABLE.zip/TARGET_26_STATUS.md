JARVIS TARGET 26 - ADVANCED DATA / GOOGLE SHEETS INTELLIGENCE
Status: LOCKED
Subtargets: 26.1 schema normalization; 26.2 field mapping; 26.3 deterministic net quantity derivation; 26.4 amount derivation; 26.5 daily/monthly summaries; 26.6 cross-sheet schema comparison; 26.7 Google Sheets adapter integration; 26.8 validation/package.
Target 26 tests: 6/6 passed.
JARVIS regression (excluding pre-existing slow Hermes XLSX suite): 112/112 passed.
Python compileall: passed.
Known unrelated baseline issue: skills/hermes/xlsx/tests/test_xlsx_skill.py::test_recalc_reports_json_both_ways does not complete within the available test window; no Target 26 code is involved.
